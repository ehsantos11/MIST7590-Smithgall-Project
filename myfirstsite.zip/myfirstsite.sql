-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 08, 2018 at 04:07 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myfirstsite`
--
CREATE DATABASE IF NOT EXISTS myfirstsite;
USE myfirstsite;
-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-01-28 22:18:36', '2018-01-28 22:18:36', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=7213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/myfirstsite', 'yes'),
(2, 'home', 'http://localhost/myfirstsite', 'yes'),
(3, 'blogname', 'Volunteer Test Site', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'ehsantos54@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:19:\"bbpress/bbpress.php\";i:1;s:47:\"participants-database/participants-database.php\";i:2;s:32:\"php-everywhere/phpeverywhere.php\";i:3;s:74:\"simple-membership-after-login-redirection/swpm-after-login-redirection.php\";i:4;s:56:\"simple-membership-form-shortcode/swpm-form-shortcode.php\";i:5;s:42:\"simple-membership/simple-wp-membership.php\";i:6;s:71:\"swpm-bulk-import-members-from-csv/swpm-bulk-import-members-from-csv.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'avior', 'yes'),
(41, 'stylesheet', 'avior', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:3:{s:27:\"ninja-forms/ninja-forms.php\";s:21:\"ninja_forms_uninstall\";s:51:\"insert-php-code-snippet/insert-php-code-snippet.php\";s:25:\"xyz_ips_network_uninstall\";s:47:\"participants-database/participants-database.php\";a:2:{i:0;s:8:\"PDb_Init\";i:1;s:12:\"on_uninstall\";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:10:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"bbp_keymaster\";a:2:{s:4:\"name\";s:9:\"Keymaster\";s:12:\"capabilities\";a:0:{}}s:13:\"bbp_spectator\";a:2:{s:4:\"name\";s:9:\"Spectator\";s:12:\"capabilities\";a:0:{}}s:11:\"bbp_blocked\";a:2:{s:4:\"name\";s:7:\"Blocked\";s:12:\"capabilities\";a:0:{}}s:13:\"bbp_moderator\";a:2:{s:4:\"name\";s:9:\"Moderator\";s:12:\"capabilities\";a:0:{}}s:15:\"bbp_participant\";a:2:{s:4:\"name\";s:11:\"Participant\";s:12:\"capabilities\";a:0:{}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:18:\"bbp_login_widget-3\";i:1;s:10:\"nav_menu-2\";i:2;s:8:\"search-2\";i:3;s:14:\"recent-posts-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:9:\"sidebar-4\";a:0:{}s:4:\"shop\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(165, 'widget_bbp_login_widget', 'a:2:{s:12:\"_multiwidget\";i:1;i:3;a:3:{s:5:\"title\";s:15:\"Volunteer Login\";s:8:\"register\";s:53:\"http://localhost/myfirstsite/membership-registration/\";s:8:\"lostpass\";s:61:\"http://localhost/myfirstsite/membership-login/password-reset/\";}}', 'yes'),
(166, 'widget_bbp_views_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(167, 'widget_bbp_search_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(168, 'widget_bbp_forums_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(169, 'widget_bbp_topics_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(170, 'widget_bbp_replies_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(171, 'widget_bbp_stats_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(193, 'ccf_subscribed', '1', 'yes'),
(196, 'wpcf7', 'a:2:{s:7:\"version\";s:3:\"5.0\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1517180363;s:7:\"version\";s:5:\"4.9.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(7114, '_transient_is_multi_author', '0', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:2:{i:2;a:2:{s:5:\"title\";s:14:\"Volunteer Menu\";s:8:\"nav_menu\";i:3;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'cron', 'a:7:{i:1518108126;a:1:{s:29:\"wp_session_garbage_collection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1518128316;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1518128332;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1518128550;a:2:{s:25:\"swpm_account_status_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:33:\"swpm_delete_pending_account_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1518128762;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519856750;a:1:{s:13:\"nf_optin_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"nf-monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2678400;}}}s:7:\"version\";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:1:{s:3:\"top\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1517575959;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:8:\"search-2\";i:1;s:18:\"bbp_login_widget-3\";i:2;s:10:\"nav_menu-2\";i:3;s:14:\"recent-posts-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(144, 'ninja_forms_settings', 'a:7:{s:11:\"date_format\";s:5:\"m/d/Y\";s:8:\"currency\";s:3:\"USD\";s:18:\"recaptcha_site_key\";s:0:\"\";s:20:\"recaptcha_secret_key\";s:0:\"\";s:14:\"recaptcha_lang\";s:0:\"\";s:19:\"delete_on_uninstall\";i:0;s:21:\"disable_admin_notices\";i:0;}', 'yes'),
(145, 'wp_nf_update_fields_batch_dfac4bcd7c28e516fc7f2987302c3978', 'a:4:{i:0;a:2:{s:2:\"id\";i:1;s:8:\"settings\";a:70:{s:5:\"label\";s:4:\"Name\";s:3:\"key\";s:4:\"name\";s:9:\"parent_id\";i:1;s:4:\"type\";s:7:\"textbox\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"1\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";s:0:\"\";s:13:\"disable_input\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"disable_browser_autocomplete\";s:0:\"\";s:4:\"mask\";s:0:\"\";s:11:\"custom_mask\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3277\";}}i:1;a:2:{s:2:\"id\";i:2;s:8:\"settings\";a:62:{s:5:\"label\";s:5:\"Email\";s:3:\"key\";s:5:\"email\";s:9:\"parent_id\";i:1;s:4:\"type\";s:5:\"email\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"2\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3281\";}}i:2;a:2:{s:2:\"id\";i:3;s:8:\"settings\";a:71:{s:5:\"label\";s:7:\"Message\";s:3:\"key\";s:7:\"message\";s:9:\"parent_id\";i:1;s:4:\"type\";s:8:\"textarea\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"3\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";s:0:\"\";s:13:\"disable_input\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"disable_browser_autocomplete\";s:0:\"\";s:12:\"textarea_rte\";s:0:\"\";s:18:\"disable_rte_mobile\";s:0:\"\";s:14:\"textarea_media\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3284\";}}i:3;a:2:{s:2:\"id\";i:4;s:8:\"settings\";a:69:{s:5:\"label\";s:6:\"Submit\";s:3:\"key\";s:6:\"submit\";s:9:\"parent_id\";i:1;s:4:\"type\";s:6:\"submit\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:16:\"processing_label\";s:10:\"Processing\";s:5:\"order\";s:1:\"5\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:44:\"submit_element_hover_styles_background-color\";s:0:\"\";s:34:\"submit_element_hover_styles_border\";s:0:\"\";s:40:\"submit_element_hover_styles_border-style\";s:0:\"\";s:40:\"submit_element_hover_styles_border-color\";s:0:\"\";s:33:\"submit_element_hover_styles_color\";s:0:\"\";s:34:\"submit_element_hover_styles_height\";s:0:\"\";s:33:\"submit_element_hover_styles_width\";s:0:\"\";s:37:\"submit_element_hover_styles_font-size\";s:0:\"\";s:34:\"submit_element_hover_styles_margin\";s:0:\"\";s:35:\"submit_element_hover_styles_padding\";s:0:\"\";s:35:\"submit_element_hover_styles_display\";s:0:\"\";s:33:\"submit_element_hover_styles_float\";s:0:\"\";s:45:\"submit_element_hover_styles_show_advanced_css\";s:1:\"0\";s:36:\"submit_element_hover_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3287\";}}}', 'no'),
(7157, '_site_transient_timeout_theme_roots', '1518102363', 'no'),
(7158, '_site_transient_theme_roots', 'a:4:{s:5:\"avior\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(683, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1518100563;s:7:\"checked\";a:4:{s:5:\"avior\";s:5:\"0.2.0\";s:13:\"twentyfifteen\";s:3:\"1.9\";s:15:\"twentyseventeen\";s:3:\"1.4\";s:13:\"twentysixteen\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(7141, '_transient_avior_categories', '1', 'yes'),
(6636, '_site_transient_timeout_browser_c89882595a0b6fb065599d15013dcdb5', '1518444092', 'no'),
(6637, '_site_transient_browser_c89882595a0b6fb065599d15013dcdb5', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"63.0.3239.132\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(260, 'pdb_admin_notices', 'a:0:{}', 'yes'),
(293, 'participants-database_options', 'a:89:{s:21:\"image_upload_location\";s:41:\"wp-content/uploads/participants-database/\";s:18:\"image_upload_limit\";s:3:\"100\";s:18:\"allowed_file_types\";s:58:\"txt,pdf,mp3,mp4a,ogg,doc,docx,odt,rtf,zip,jpg,jpeg,gif,png\";s:13:\"default_image\";s:57:\"/wp-content/plugins/participants-database/ui/no-image.png\";s:10:\"image_link\";s:1:\"0\";s:11:\"file_delete\";s:1:\"0\";s:10:\"allow_tags\";s:1:\"1\";s:10:\"make_links\";s:1:\"0\";s:13:\"email_protect\";s:1:\"0\";s:19:\"empty_field_message\";s:25:\"The %s field is required.\";s:21:\"invalid_field_message\";s:37:\"The %s field appears to be incorrect.\";s:25:\"nonmatching_field_message\";s:37:\"The %s field must match the %s field.\";s:21:\"captcha_field_message\";s:33:\"Pleast try the %s question again.\";s:17:\"field_error_style\";s:22:\"border: 1px solid red;\";s:20:\"mark_required_fields\";s:1:\"0\";s:21:\"required_field_marker\";s:29:\"%s<span class=\"reqd\">*</span>\";s:18:\"signup_button_text\";s:6:\"Submit\";s:18:\"signup_thanks_page\";s:4:\"none\";s:30:\"signup_show_group_descriptions\";s:1:\"0\";s:12:\"unique_field\";s:5:\"email\";s:12:\"unique_email\";s:1:\"0\";s:23:\"duplicate_field_message\";s:60:\"A record with that %s already exists. Please choose another.\";s:25:\"send_signup_receipt_email\";s:1:\"0\";s:20:\"receipt_from_address\";s:20:\"ehsantos54@gmail.com\";s:17:\"receipt_from_name\";s:19:\"Volunteer Test Site\";s:28:\"signup_receipt_email_subject\";s:44:\"You\'ve just signed up on Volunteer Test Site\";s:25:\"signup_receipt_email_body\";s:254:\"<p>Thank you, [first_name], for signing up with Volunteer Test Site.</p><p>You may complete your registration with additional information or update your information by visiting this private link at any time: <a href=\"[record_link]\">[record_link]</a>.</p>\";s:13:\"signup_thanks\";s:255:\"<p>Thank you, <strong>[first_name]</strong>, for volunteering!</p><p>Your  volunteer information has been updated! You will receive an email acknowledgement shortly. You may update your volunteer information by visiting the link provided in the email.</p>\";s:24:\"send_signup_notify_email\";s:1:\"0\";s:29:\"email_signup_notify_addresses\";s:20:\"ehsantos54@gmail.com\";s:27:\"email_signup_notify_subject\";s:33:\"New signup on Volunteer Test Site\";s:24:\"email_signup_notify_body\";s:196:\"<p>A new signup has been submitted</p><ul><li>Name: [first_name] [last_name]</li><li>Email: [email]</li></ul><p>Edit this new record here: <a href=\"[admin_record_link]\">[admin_record_link]</a></p>\";s:17:\"registration_page\";s:2:\"48\";s:23:\"show_group_descriptions\";s:1:\"0\";s:18:\"save_changes_label\";s:17:\"Save Your Changes\";s:19:\"save_changes_button\";s:4:\"Save\";s:22:\"record_updated_message\";s:33:\"Your information has been updated\";s:23:\"no_record_error_message\";s:20:\"No record was found.\";s:22:\"no_record_use_template\";s:1:\"0\";s:31:\"send_record_update_notify_email\";s:1:\"0\";s:27:\"record_update_email_subject\";s:53:\"A record has just been updated on Volunteer Test Site\";s:24:\"record_update_email_body\";s:269:\"<p>The following record was updated on [date]:</p><ul><li>Name: [first_name] [last_name]</li><li>Address: [address]</li><li>[city], [state], [country]</li><li>Phone: [phone]</li><li>Email: [email]</li></ul><p>Edit this record <a href=\"[admin_record_link]\">here.</a></p>\";s:10:\"list_limit\";s:2:\"10\";s:24:\"single_record_link_field\";s:8:\"activity\";s:18:\"single_record_page\";s:2:\"54\";s:18:\"no_records_message\";s:16:\"No Records Found\";s:10:\"show_count\";s:1:\"0\";s:14:\"count_template\";s:48:\"Total Records Found: %1$s, showing %2$s per page\";s:17:\"list_default_sort\";s:12:\"date_updated\";s:23:\"list_default_sort_order\";s:4:\"desc\";s:12:\"empty_search\";s:1:\"0\";s:18:\"show_retrieve_link\";s:1:\"0\";s:18:\"retrieve_link_text\";s:63:\"Forget your private link? Click here to have it emailed to you.\";s:19:\"link_retrieval_page\";s:4:\"none\";s:24:\"retrieve_link_identifier\";s:5:\"email\";s:15:\"id_field_prompt\";s:58:\"Type in your %s, your private link will be emailed to you.\";s:27:\"retrieve_link_email_subject\";s:48:\"Here is your private link on Volunteer Test Site\";s:24:\"retrieve_link_email_body\";s:120:\"<p>Here is the private link you requested from Volunteer Test Site:</p><p><a href=\"[record_link]\">[record_link]</a>.</p>\";s:31:\"send_retrieve_link_notify_email\";s:1:\"0\";s:28:\"retrieve_link_notify_subject\";s:61:\"A Lost Private Link has been requested on Volunteer Test Site\";s:25:\"retrieve_link_notify_body\";s:120:\"<p>A lost private link has been requested by:</p><ul><li>Name: [first_name] [last_name]</li><li>Email: [email]</li></ul>\";s:24:\"identifier_field_message\";s:42:\"A record matching that %s cannot be found.\";s:18:\"admin_default_sort\";s:12:\"date_updated\";s:24:\"admin_default_sort_order\";s:4:\"desc\";s:16:\"admin_thumbnails\";s:1:\"0\";s:18:\"admin_horiz_scroll\";s:1:\"0\";s:22:\"record_edit_capability\";s:17:\"edit_others_posts\";s:23:\"plugin_admin_capability\";s:14:\"manage_options\";s:25:\"editor_allowed_csv_export\";s:1:\"0\";s:14:\"use_plugin_css\";s:1:\"1\";s:16:\"rich_text_editor\";s:1:\"1\";s:14:\"enable_wpautop\";s:11:\"the_content\";s:16:\"strip_linebreaks\";s:1:\"0\";s:28:\"use_pagination_scroll_anchor\";s:1:\"1\";s:27:\"primary_email_address_field\";s:5:\"email\";s:10:\"html_email\";s:1:\"1\";s:12:\"strict_dates\";s:1:\"0\";s:17:\"input_date_format\";s:6:\"F j, Y\";s:9:\"show_time\";s:1:\"0\";s:13:\"strict_search\";s:1:\"0\";s:11:\"ajax_search\";s:1:\"1\";s:16:\"use_php_sessions\";s:1:\"0\";s:11:\"cookie_name\";s:14:\"pdb_wp_session\";s:26:\"disable_live_notifications\";s:1:\"0\";s:27:\"files_use_content_base_path\";s:1:\"0\";s:27:\"allow_record_timestamp_edit\";s:1:\"0\";s:10:\"custom_css\";s:0:\"\";s:9:\"print_css\";s:91:\"/* this prevents the search controls from printing */\r\n.pdb-searchform {\r\n	display:none;\r\n}\";s:16:\"custom_admin_css\";s:0:\"\";}', 'yes'),
(1126, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1518100563;s:8:\"response\";a:1:{s:47:\"participants-database/participants-database.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:35:\"w.org/plugins/participants-database\";s:4:\"slug\";s:21:\"participants-database\";s:6:\"plugin\";s:47:\"participants-database/participants-database.php\";s:11:\"new_version\";s:7:\"1.7.7.6\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/participants-database/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/participants-database.1.7.7.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:74:\"https://ps.w.org/participants-database/assets/icon-128x128.jpg?rev=1389620\";s:2:\"2x\";s:74:\"https://ps.w.org/participants-database/assets/icon-256x256.jpg?rev=1389807\";s:7:\"default\";s:74:\"https://ps.w.org/participants-database/assets/icon-256x256.jpg?rev=1389807\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:77:\"https://ps.w.org/participants-database/assets/banner-1544x500.jpg?rev=1494923\";s:2:\"1x\";s:76:\"https://ps.w.org/participants-database/assets/banner-772x250.jpg?rev=1388873\";s:7:\"default\";s:77:\"https://ps.w.org/participants-database/assets/banner-1544x500.jpg?rev=1494923\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:9:{s:35:\"advanced-cf7-db/advanced-cf7-db.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/advanced-cf7-db\";s:4:\"slug\";s:15:\"advanced-cf7-db\";s:6:\"plugin\";s:35:\"advanced-cf7-db/advanced-cf7-db.php\";s:11:\"new_version\";s:5:\"1.2.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/advanced-cf7-db/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/advanced-cf7-db.1.2.0.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:68:\"https://ps.w.org/advanced-cf7-db/assets/icon-128x128.jpg?rev=1696186\";s:2:\"2x\";s:68:\"https://ps.w.org/advanced-cf7-db/assets/icon-256x256.jpg?rev=1696186\";s:7:\"default\";s:68:\"https://ps.w.org/advanced-cf7-db/assets/icon-256x256.jpg?rev=1696186\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:71:\"https://ps.w.org/advanced-cf7-db/assets/banner-1544x500.jpg?rev=1696186\";s:2:\"1x\";s:70:\"https://ps.w.org/advanced-cf7-db/assets/banner-772x250.jpg?rev=1696186\";s:7:\"default\";s:71:\"https://ps.w.org/advanced-cf7-db/assets/banner-1544x500.jpg?rev=1696186\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"bbpress/bbpress.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/bbpress\";s:4:\"slug\";s:7:\"bbpress\";s:6:\"plugin\";s:19:\"bbpress/bbpress.php\";s:11:\"new_version\";s:6:\"2.5.14\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/bbpress/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/bbpress.2.5.14.zip\";s:5:\"icons\";a:4:{s:2:\"1x\";s:60:\"https://ps.w.org/bbpress/assets/icon-128x128.png?rev=1534011\";s:2:\"2x\";s:60:\"https://ps.w.org/bbpress/assets/icon-256x256.png?rev=1534011\";s:3:\"svg\";s:51:\"https://ps.w.org/bbpress/assets/icon.svg?rev=978290\";s:7:\"default\";s:51:\"https://ps.w.org/bbpress/assets/icon.svg?rev=978290\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/bbpress/assets/banner-1544x500.png?rev=567403\";s:2:\"1x\";s:61:\"https://ps.w.org/bbpress/assets/banner-772x250.png?rev=478663\";s:7:\"default\";s:62:\"https://ps.w.org/bbpress/assets/banner-1544x500.png?rev=567403\";}s:11:\"banners_rtl\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/bbpress/assets/banner-1544x500-rtl.png?rev=1534011\";s:2:\"1x\";s:66:\"https://ps.w.org/bbpress/assets/banner-772x250-rtl.png?rev=1534011\";s:7:\"default\";s:67:\"https://ps.w.org/bbpress/assets/banner-1544x500-rtl.png?rev=1534011\";}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:3:\"5.0\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:7:\"default\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";s:7:\"default\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:7:\"default\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";s:7:\"default\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:32:\"php-everywhere/phpeverywhere.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/php-everywhere\";s:4:\"slug\";s:14:\"php-everywhere\";s:6:\"plugin\";s:32:\"php-everywhere/phpeverywhere.php\";s:11:\"new_version\";s:5:\"1.4.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/php-everywhere/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/php-everywhere.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/php-everywhere/assets/banner-1544x500.png?rev=989425\";s:2:\"1x\";s:68:\"https://ps.w.org/php-everywhere/assets/banner-772x250.png?rev=989425\";s:7:\"default\";s:69:\"https://ps.w.org/php-everywhere/assets/banner-1544x500.png?rev=989425\";}s:11:\"banners_rtl\";a:0:{}}s:74:\"simple-membership-after-login-redirection/swpm-after-login-redirection.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:55:\"w.org/plugins/simple-membership-after-login-redirection\";s:4:\"slug\";s:41:\"simple-membership-after-login-redirection\";s:6:\"plugin\";s:74:\"simple-membership-after-login-redirection/swpm-after-login-redirection.php\";s:11:\"new_version\";s:4:\"v1.3\";s:3:\"url\";s:72:\"https://wordpress.org/plugins/simple-membership-after-login-redirection/\";s:7:\"package\";s:84:\"https://downloads.wordpress.org/plugin/simple-membership-after-login-redirection.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:56:\"simple-membership-form-shortcode/swpm-form-shortcode.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:46:\"w.org/plugins/simple-membership-form-shortcode\";s:4:\"slug\";s:32:\"simple-membership-form-shortcode\";s:6:\"plugin\";s:56:\"simple-membership-form-shortcode/swpm-form-shortcode.php\";s:11:\"new_version\";s:3:\"1.1\";s:3:\"url\";s:63:\"https://wordpress.org/plugins/simple-membership-form-shortcode/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/simple-membership-form-shortcode.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:42:\"simple-membership/simple-wp-membership.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/simple-membership\";s:4:\"slug\";s:17:\"simple-membership\";s:6:\"plugin\";s:42:\"simple-membership/simple-wp-membership.php\";s:11:\"new_version\";s:5:\"3.6.0\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/simple-membership/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/simple-membership.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:69:\"https://ps.w.org/simple-membership/assets/icon-128x128.png?rev=974529\";s:7:\"default\";s:69:\"https://ps.w.org/simple-membership/assets/icon-128x128.png?rev=974529\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:71:\"https://ps.w.org/simple-membership/assets/banner-772x250.jpg?rev=923517\";s:7:\"default\";s:71:\"https://ps.w.org/simple-membership/assets/banner-772x250.jpg?rev=923517\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(402, 'pdb-csv_import_params', 'a:4:{s:19:\"delimiter_character\";s:4:\"auto\";s:19:\"enclosure_character\";s:4:\"auto\";s:11:\"match_field\";s:5:\"email\";s:16:\"match_preference\";s:1:\"1\";}', 'yes'),
(751, 'category_children', 'a:0:{}', 'yes'),
(1127, 'PDb_Db_version', '1.0', 'yes'),
(979, 'widget_phpeverywherewidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(957, 'widget_xyz_insert_php_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(685, 'current_theme', 'Avior', 'yes'),
(686, 'theme_mods_avior', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:6:\"menu-1\";i:2;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(687, 'theme_switched', '', 'yes'),
(129, 'can_compress_scripts', '1', 'no'),
(6672, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-3.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.3\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-3.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-rollback-3.zip\";}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.3\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1518100503;s:15:\"version_checked\";s:5:\"4.9.3\";s:12:\"translations\";a:0:{}}', 'no'),
(6675, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"ehsantos54@gmail.com\";s:7:\"version\";s:5:\"4.9.3\";s:9:\"timestamp\";i:1517890396;}', 'no'),
(143, 'ninja_forms_version', '3.2.8', 'yes'),
(138, 'recently_activated', 'a:3:{s:51:\"insert-php-code-snippet/insert-php-code-snippet.php\";i:1517583936;s:35:\"advanced-cf7-db/advanced-cf7-db.php\";i:1517549468;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1517549327;}', 'yes'),
(154, 'swpm_db_version', '1.2', 'yes'),
(155, 'swpm-settings', 'a:41:{i:0;b:0;s:16:\"join-us-page-url\";s:53:\"http://localhost/myfirstsite/membership-registration/\";s:21:\"registration-page-url\";s:53:\"http://localhost/myfirstsite/membership-registration/\";s:14:\"login-page-url\";s:46:\"http://localhost/myfirstsite/membership-login/\";s:16:\"profile-page-url\";s:65:\"http://localhost/myfirstsite/membership-login/membership-profile/\";s:14:\"reset-page-url\";s:61:\"http://localhost/myfirstsite/membership-login/password-reset/\";s:25:\"reg-complete-mail-subject\";s:29:\"Your registration is complete\";s:22:\"reg-complete-mail-body\";s:211:\"Dear {first_name} {last_name}\n\nYour registration is now complete!\n\nRegistration details:\nUsername: {user_name}\nPassword: {password}\n\nPlease login to the member area at the following URL:\n\n{login_link}\n\nThank You\";s:32:\"reg-prompt-complete-mail-subject\";s:26:\"Complete your registration\";s:29:\"reg-prompt-complete-mail-body\";s:146:\"Dear {first_name} {last_name}\n\nThank you for joining us!\n\nPlease complete your registration by visiting the following link:\n\n{reg_link}\n\nThank You\";s:29:\"upgrade-complete-mail-subject\";s:44:\"Subject for email sent after account upgrade\";s:26:\"upgrade-complete-mail-body\";s:73:\"Dear {first_name} {last_name}\n\nYour Account Has Been Upgraded.\n\nThank You\";s:18:\"reset-mail-subject\";s:33:\"Volunteer Test Site: New Password\";s:15:\"reset-mail-body\";s:213:\"Dear {first_name} {last_name}\n\nHere is your new password:\n\nUsername: {user_name}\nPassword: {password}\n\nYou can change the password from the edit profile section of the site (after you log into the site)\n\nThank You\";s:28:\"account-change-email-subject\";s:16:\"Account Updated!\";s:25:\"account-change-email-body\";s:149:\"Dear {first_name} {last_name},\n\nYour account status has been updated! Please login to the member area at the following URL:\n\n {login_link}\n\nThank You\";s:10:\"email-from\";s:20:\"ehsantos54@gmail.com\";s:31:\"reg-complete-mail-subject-admin\";s:39:\"Notification of New Member Registration\";s:28:\"reg-complete-mail-body-admin\";s:242:\"A new member has completed the registration.\n\nUsername: {user_name}\nEmail: {email}\n\nPlease login to the admin dashboard to view details of this user.\n\nYou can customize this email message from the Email Settings menu of the plugin.\n\nThank You\";s:33:\"bulk-activate-notify-mail-subject\";s:18:\"Account Activated!\";s:30:\"bulk-activate-notify-mail-body\";s:87:\"Hi,\n\nYour account has been activated!\n\nYou can now login to the member area.\n\nThank You\";s:19:\"swpm-active-version\";s:5:\"3.6.0\";s:13:\"hide-adminbar\";s:27:\"checked=&#039;checked&#039;\";s:24:\"show-adminbar-admin-only\";s:0:\"\";s:30:\"disable-access-to-wp-dashboard\";s:0:\"\";s:18:\"protect-everything\";s:0:\"\";s:22:\"enable-free-membership\";s:27:\"checked=&#039;checked&#039;\";s:14:\"enable-moretag\";s:0:\"\";s:12:\"enable-debug\";s:0:\"\";s:22:\"enable-sandbox-testing\";s:0:\"\";s:18:\"free-membership-id\";i:2;s:22:\"default-account-status\";s:6:\"active\";s:24:\"members-login-to-comment\";s:0:\"\";s:28:\"enable-expired-account-login\";s:0:\"\";s:22:\"allow-account-deletion\";s:0:\"\";s:18:\"force-wp-user-sync\";s:0:\"\";s:22:\"use-wordpress-timezone\";s:0:\"\";s:22:\"delete-pending-account\";s:1:\"0\";s:33:\"admin-dashboard-access-permission\";s:14:\"manage_options\";s:16:\"renewal-page-url\";s:0:\"\";s:28:\"after-rego-redirect-page-url\";s:46:\"http://localhost/myfirstsite/membership-login/\";}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(147, 'nf_form_1', 'a:4:{s:2:\"id\";i:1;s:6:\"fields\";a:4:{i:0;a:2:{s:2:\"id\";i:1;s:8:\"settings\";a:70:{s:5:\"label\";s:4:\"Name\";s:3:\"key\";s:4:\"name\";s:9:\"parent_id\";i:1;s:4:\"type\";s:7:\"textbox\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"1\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";s:0:\"\";s:13:\"disable_input\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"disable_browser_autocomplete\";s:0:\"\";s:4:\"mask\";s:0:\"\";s:11:\"custom_mask\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3277\";}}i:1;a:2:{s:2:\"id\";i:2;s:8:\"settings\";a:62:{s:5:\"label\";s:5:\"Email\";s:3:\"key\";s:5:\"email\";s:9:\"parent_id\";i:1;s:4:\"type\";s:5:\"email\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"2\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3281\";}}i:2;a:2:{s:2:\"id\";i:3;s:8:\"settings\";a:71:{s:5:\"label\";s:7:\"Message\";s:3:\"key\";s:7:\"message\";s:9:\"parent_id\";i:1;s:4:\"type\";s:8:\"textarea\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:9:\"label_pos\";s:5:\"above\";s:8:\"required\";s:1:\"1\";s:5:\"order\";s:1:\"3\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";s:0:\"\";s:13:\"disable_input\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:9:\"desc_text\";s:0:\"\";s:28:\"disable_browser_autocomplete\";s:0:\"\";s:12:\"textarea_rte\";s:0:\"\";s:18:\"disable_rte_mobile\";s:0:\"\";s:14:\"textarea_media\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3284\";}}i:3;a:2:{s:2:\"id\";i:4;s:8:\"settings\";a:69:{s:5:\"label\";s:6:\"Submit\";s:3:\"key\";s:6:\"submit\";s:9:\"parent_id\";i:1;s:4:\"type\";s:6:\"submit\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:16:\"processing_label\";s:10:\"Processing\";s:5:\"order\";s:1:\"5\";s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:28:\"wrap_styles_background-color\";s:0:\"\";s:18:\"wrap_styles_border\";s:0:\"\";s:24:\"wrap_styles_border-style\";s:0:\"\";s:24:\"wrap_styles_border-color\";s:0:\"\";s:17:\"wrap_styles_color\";s:0:\"\";s:18:\"wrap_styles_height\";s:0:\"\";s:17:\"wrap_styles_width\";s:0:\"\";s:21:\"wrap_styles_font-size\";s:0:\"\";s:18:\"wrap_styles_margin\";s:0:\"\";s:19:\"wrap_styles_padding\";s:0:\"\";s:19:\"wrap_styles_display\";s:0:\"\";s:17:\"wrap_styles_float\";s:0:\"\";s:29:\"wrap_styles_show_advanced_css\";s:1:\"0\";s:20:\"wrap_styles_advanced\";s:0:\"\";s:29:\"label_styles_background-color\";s:0:\"\";s:19:\"label_styles_border\";s:0:\"\";s:25:\"label_styles_border-style\";s:0:\"\";s:25:\"label_styles_border-color\";s:0:\"\";s:18:\"label_styles_color\";s:0:\"\";s:19:\"label_styles_height\";s:0:\"\";s:18:\"label_styles_width\";s:0:\"\";s:22:\"label_styles_font-size\";s:0:\"\";s:19:\"label_styles_margin\";s:0:\"\";s:20:\"label_styles_padding\";s:0:\"\";s:20:\"label_styles_display\";s:0:\"\";s:18:\"label_styles_float\";s:0:\"\";s:30:\"label_styles_show_advanced_css\";s:1:\"0\";s:21:\"label_styles_advanced\";s:0:\"\";s:31:\"element_styles_background-color\";s:0:\"\";s:21:\"element_styles_border\";s:0:\"\";s:27:\"element_styles_border-style\";s:0:\"\";s:27:\"element_styles_border-color\";s:0:\"\";s:20:\"element_styles_color\";s:0:\"\";s:21:\"element_styles_height\";s:0:\"\";s:20:\"element_styles_width\";s:0:\"\";s:24:\"element_styles_font-size\";s:0:\"\";s:21:\"element_styles_margin\";s:0:\"\";s:22:\"element_styles_padding\";s:0:\"\";s:22:\"element_styles_display\";s:0:\"\";s:20:\"element_styles_float\";s:0:\"\";s:32:\"element_styles_show_advanced_css\";s:1:\"0\";s:23:\"element_styles_advanced\";s:0:\"\";s:44:\"submit_element_hover_styles_background-color\";s:0:\"\";s:34:\"submit_element_hover_styles_border\";s:0:\"\";s:40:\"submit_element_hover_styles_border-style\";s:0:\"\";s:40:\"submit_element_hover_styles_border-color\";s:0:\"\";s:33:\"submit_element_hover_styles_color\";s:0:\"\";s:34:\"submit_element_hover_styles_height\";s:0:\"\";s:33:\"submit_element_hover_styles_width\";s:0:\"\";s:37:\"submit_element_hover_styles_font-size\";s:0:\"\";s:34:\"submit_element_hover_styles_margin\";s:0:\"\";s:35:\"submit_element_hover_styles_padding\";s:0:\"\";s:35:\"submit_element_hover_styles_display\";s:0:\"\";s:33:\"submit_element_hover_styles_float\";s:0:\"\";s:45:\"submit_element_hover_styles_show_advanced_css\";s:1:\"0\";s:36:\"submit_element_hover_styles_advanced\";s:0:\"\";s:7:\"cellcid\";s:5:\"c3287\";}}}s:7:\"actions\";a:4:{i:0;a:2:{s:2:\"id\";i:1;s:8:\"settings\";a:25:{s:5:\"title\";s:0:\"\";s:3:\"key\";s:0:\"\";s:4:\"type\";s:4:\"save\";s:6:\"active\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:44\";s:5:\"label\";s:16:\"Store Submission\";s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";s:0:\"\";s:10:\"conditions\";a:6:{s:9:\"collapsed\";s:0:\"\";s:7:\"process\";s:1:\"1\";s:9:\"connector\";s:3:\"all\";s:4:\"when\";a:1:{i:0;a:6:{s:9:\"connector\";s:3:\"AND\";s:3:\"key\";s:0:\"\";s:10:\"comparator\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"when\";}}s:4:\"then\";a:1:{i:0;a:5:{s:3:\"key\";s:0:\"\";s:7:\"trigger\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"then\";}}s:4:\"else\";a:0:{}}s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:0:\"\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:0:\"\";s:13:\"email_subject\";s:0:\"\";s:13:\"email_message\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:8:\"reply_to\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:10:\"attach_csv\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";s:19:\"email_message_plain\";s:0:\"\";}}i:1;a:2:{s:2:\"id\";i:2;s:8:\"settings\";a:26:{s:5:\"title\";s:0:\"\";s:3:\"key\";s:0:\"\";s:4:\"type\";s:5:\"email\";s:6:\"active\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:44\";s:5:\"label\";s:18:\"Email Confirmation\";s:2:\"to\";s:13:\"{field:email}\";s:7:\"subject\";s:24:\"This is an email action.\";s:7:\"message\";s:19:\"Hello, Ninja Forms!\";s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";s:0:\"\";s:10:\"conditions\";a:6:{s:9:\"collapsed\";s:0:\"\";s:7:\"process\";s:1:\"1\";s:9:\"connector\";s:3:\"all\";s:4:\"when\";a:0:{}s:4:\"then\";a:1:{i:0;a:5:{s:3:\"key\";s:0:\"\";s:7:\"trigger\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"then\";}}s:4:\"else\";a:0:{}}s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:0:\"\";s:3:\"tag\";s:0:\"\";s:13:\"email_subject\";s:24:\"Submission Confirmation \";s:13:\"email_message\";s:29:\"<p>{all_fields_table}<br></p>\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:8:\"reply_to\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:10:\"attach_csv\";s:0:\"\";s:19:\"email_message_plain\";s:0:\"\";}}i:2;a:2:{s:2:\"id\";i:3;s:8:\"settings\";a:24:{s:5:\"title\";s:0:\"\";s:3:\"key\";s:0:\"\";s:4:\"type\";s:5:\"email\";s:6:\"active\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:44\";s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";s:0:\"\";s:5:\"label\";s:18:\"Email Notification\";s:10:\"conditions\";a:6:{s:9:\"collapsed\";s:0:\"\";s:7:\"process\";s:1:\"1\";s:9:\"connector\";s:3:\"all\";s:4:\"when\";a:1:{i:0;a:6:{s:9:\"connector\";s:3:\"AND\";s:3:\"key\";s:0:\"\";s:10:\"comparator\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"when\";}}s:4:\"then\";a:1:{i:0;a:5:{s:3:\"key\";s:0:\"\";s:7:\"trigger\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"then\";}}s:4:\"else\";a:0:{}}s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:0:\"\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:20:\"{system:admin_email}\";s:13:\"email_subject\";s:29:\"New message from {field:name}\";s:13:\"email_message\";s:60:\"<p>{field:message}</p><p>-{field:name} ( {field:email} )</p>\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:8:\"reply_to\";s:13:\"{field:email}\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:10:\"attach_csv\";s:1:\"0\";s:19:\"email_message_plain\";s:0:\"\";}}i:3;a:2:{s:2:\"id\";i:4;s:8:\"settings\";a:27:{s:5:\"title\";s:0:\"\";s:3:\"key\";s:0:\"\";s:4:\"type\";s:14:\"successmessage\";s:6:\"active\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:44\";s:5:\"label\";s:15:\"Success Message\";s:7:\"message\";s:47:\"Thank you {field:name} for filling out my form!\";s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";s:0:\"\";s:10:\"conditions\";a:6:{s:9:\"collapsed\";s:0:\"\";s:7:\"process\";s:1:\"1\";s:9:\"connector\";s:3:\"all\";s:4:\"when\";a:1:{i:0;a:6:{s:9:\"connector\";s:3:\"AND\";s:3:\"key\";s:0:\"\";s:10:\"comparator\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"when\";}}s:4:\"then\";a:1:{i:0;a:5:{s:3:\"key\";s:0:\"\";s:7:\"trigger\";s:0:\"\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:5:\"field\";s:9:\"modelType\";s:4:\"then\";}}s:4:\"else\";a:0:{}}s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:0:\"\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:0:\"\";s:13:\"email_subject\";s:0:\"\";s:13:\"email_message\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:8:\"reply_to\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:10:\"attach_csv\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";s:11:\"success_msg\";s:89:\"<p>Form submitted successfully.</p><p>A confirmation email was sent to {field:email}.</p>\";s:19:\"email_message_plain\";s:0:\"\";}}}s:8:\"settings\";a:99:{s:5:\"title\";s:10:\"Contact Me\";s:3:\"key\";s:0:\"\";s:10:\"created_at\";s:19:\"2018-01-28 22:21:43\";s:17:\"default_label_pos\";s:5:\"above\";s:10:\"conditions\";a:0:{}s:10:\"objectType\";s:12:\"Form Setting\";s:10:\"editActive\";s:0:\"\";s:10:\"show_title\";s:1:\"1\";s:14:\"clear_complete\";s:1:\"1\";s:13:\"hide_complete\";s:1:\"1\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"add_submit\";s:1:\"1\";s:9:\"logged_in\";s:0:\"\";s:17:\"not_logged_in_msg\";s:0:\"\";s:16:\"sub_limit_number\";s:0:\"\";s:13:\"sub_limit_msg\";s:0:\"\";s:12:\"calculations\";a:0:{}s:15:\"formContentData\";a:4:{i:0;a:2:{s:5:\"order\";s:1:\"0\";s:5:\"cells\";a:1:{i:0;a:3:{s:5:\"order\";s:1:\"0\";s:6:\"fields\";a:1:{i:0;s:4:\"name\";}s:5:\"width\";s:3:\"100\";}}}i:1;a:2:{s:5:\"order\";s:1:\"1\";s:5:\"cells\";a:1:{i:0;a:3:{s:5:\"order\";s:1:\"0\";s:6:\"fields\";a:1:{i:0;s:5:\"email\";}s:5:\"width\";s:3:\"100\";}}}i:2;a:2:{s:5:\"order\";s:1:\"2\";s:5:\"cells\";a:1:{i:0;a:3:{s:5:\"order\";s:1:\"0\";s:6:\"fields\";a:1:{i:0;s:7:\"message\";}s:5:\"width\";s:3:\"100\";}}}i:3;a:2:{s:5:\"order\";s:1:\"3\";s:5:\"cells\";a:1:{i:0;a:3:{s:5:\"order\";s:1:\"0\";s:6:\"fields\";a:1:{i:0;s:6:\"submit\";}s:5:\"width\";s:3:\"100\";}}}}s:33:\"container_styles_background-color\";s:0:\"\";s:23:\"container_styles_border\";s:0:\"\";s:29:\"container_styles_border-style\";s:0:\"\";s:29:\"container_styles_border-color\";s:0:\"\";s:22:\"container_styles_color\";s:0:\"\";s:23:\"container_styles_height\";s:0:\"\";s:22:\"container_styles_width\";s:0:\"\";s:26:\"container_styles_font-size\";s:0:\"\";s:23:\"container_styles_margin\";s:0:\"\";s:24:\"container_styles_padding\";s:0:\"\";s:24:\"container_styles_display\";s:0:\"\";s:22:\"container_styles_float\";s:0:\"\";s:34:\"container_styles_show_advanced_css\";s:1:\"0\";s:25:\"container_styles_advanced\";s:0:\"\";s:29:\"title_styles_background-color\";s:0:\"\";s:19:\"title_styles_border\";s:0:\"\";s:25:\"title_styles_border-style\";s:0:\"\";s:25:\"title_styles_border-color\";s:0:\"\";s:18:\"title_styles_color\";s:0:\"\";s:19:\"title_styles_height\";s:0:\"\";s:18:\"title_styles_width\";s:0:\"\";s:22:\"title_styles_font-size\";s:0:\"\";s:19:\"title_styles_margin\";s:0:\"\";s:20:\"title_styles_padding\";s:0:\"\";s:20:\"title_styles_display\";s:0:\"\";s:18:\"title_styles_float\";s:0:\"\";s:30:\"title_styles_show_advanced_css\";s:1:\"0\";s:21:\"title_styles_advanced\";s:0:\"\";s:27:\"row_styles_background-color\";s:0:\"\";s:17:\"row_styles_border\";s:0:\"\";s:23:\"row_styles_border-style\";s:0:\"\";s:23:\"row_styles_border-color\";s:0:\"\";s:16:\"row_styles_color\";s:0:\"\";s:17:\"row_styles_height\";s:0:\"\";s:16:\"row_styles_width\";s:0:\"\";s:20:\"row_styles_font-size\";s:0:\"\";s:17:\"row_styles_margin\";s:0:\"\";s:18:\"row_styles_padding\";s:0:\"\";s:18:\"row_styles_display\";s:0:\"\";s:28:\"row_styles_show_advanced_css\";s:1:\"0\";s:19:\"row_styles_advanced\";s:0:\"\";s:31:\"row-odd_styles_background-color\";s:0:\"\";s:21:\"row-odd_styles_border\";s:0:\"\";s:27:\"row-odd_styles_border-style\";s:0:\"\";s:27:\"row-odd_styles_border-color\";s:0:\"\";s:20:\"row-odd_styles_color\";s:0:\"\";s:21:\"row-odd_styles_height\";s:0:\"\";s:20:\"row-odd_styles_width\";s:0:\"\";s:24:\"row-odd_styles_font-size\";s:0:\"\";s:21:\"row-odd_styles_margin\";s:0:\"\";s:22:\"row-odd_styles_padding\";s:0:\"\";s:22:\"row-odd_styles_display\";s:0:\"\";s:32:\"row-odd_styles_show_advanced_css\";s:1:\"0\";s:23:\"row-odd_styles_advanced\";s:0:\"\";s:35:\"success-msg_styles_background-color\";s:0:\"\";s:25:\"success-msg_styles_border\";s:0:\"\";s:31:\"success-msg_styles_border-style\";s:0:\"\";s:31:\"success-msg_styles_border-color\";s:0:\"\";s:24:\"success-msg_styles_color\";s:0:\"\";s:25:\"success-msg_styles_height\";s:0:\"\";s:24:\"success-msg_styles_width\";s:0:\"\";s:28:\"success-msg_styles_font-size\";s:0:\"\";s:25:\"success-msg_styles_margin\";s:0:\"\";s:26:\"success-msg_styles_padding\";s:0:\"\";s:26:\"success-msg_styles_display\";s:0:\"\";s:36:\"success-msg_styles_show_advanced_css\";s:1:\"0\";s:27:\"success-msg_styles_advanced\";s:0:\"\";s:33:\"error_msg_styles_background-color\";s:0:\"\";s:23:\"error_msg_styles_border\";s:0:\"\";s:29:\"error_msg_styles_border-style\";s:0:\"\";s:29:\"error_msg_styles_border-color\";s:0:\"\";s:22:\"error_msg_styles_color\";s:0:\"\";s:23:\"error_msg_styles_height\";s:0:\"\";s:22:\"error_msg_styles_width\";s:0:\"\";s:26:\"error_msg_styles_font-size\";s:0:\"\";s:23:\"error_msg_styles_margin\";s:0:\"\";s:24:\"error_msg_styles_padding\";s:0:\"\";s:24:\"error_msg_styles_display\";s:0:\"\";s:34:\"error_msg_styles_show_advanced_css\";s:1:\"0\";s:25:\"error_msg_styles_advanced\";s:0:\"\";}}', 'yes'),
(148, 'widget_ninja_forms_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(149, 'ninja_forms_optin_reported', '1', 'yes'),
(150, 'nf_admin_notice', 'a:2:{s:16:\"one_week_support\";a:2:{s:5:\"start\";s:8:\"2/4/2018\";s:3:\"int\";i:7;}s:14:\"allow_tracking\";a:2:{s:5:\"start\";s:9:\"1/28/2018\";s:3:\"int\";i:0;}}', 'yes'),
(151, 'ninja_forms_do_not_allow_tracking', '1', 'yes'),
(172, '_bbp_private_forums', 'a:0:{}', 'yes'),
(173, '_bbp_hidden_forums', 'a:0:{}', 'yes'),
(174, '_bbp_db_version', '250', 'yes'),
(156, 'swpm_private_key_one', '5a6e4d26d341b2.81289797', 'yes'),
(158, 'nf_form_2', 'a:7:{s:2:\"id\";i:2;s:20:\"show_publish_options\";b:0;s:6:\"fields\";a:5:{i:0;a:2:{s:8:\"settings\";a:19:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:1;s:4:\"type\";s:4:\"date\";s:5:\"label\";s:14:\"Date Performed\";s:3:\"key\";s:28:\"date_performed_1517178228230\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:11:\"date_format\";s:0:\"\";s:16:\"year_range_start\";s:0:\"\";s:14:\"year_range_end\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}s:2:\"id\";s:1:\"5\";}i:1;a:2:{s:8:\"settings\";a:22:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:2;s:4:\"type\";s:7:\"textbox\";s:5:\"label\";s:8:\"Activity\";s:3:\"key\";s:22:\"activity_1517178202399\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:7:\"default\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:4:\"mask\";s:0:\"\";s:11:\"custom_mask\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}s:2:\"id\";s:1:\"6\";}i:2;a:2:{s:8:\"settings\";a:15:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:999;s:4:\"type\";s:10:\"listselect\";s:5:\"label\";s:7:\"Project\";s:3:\"key\";s:21:\"project_1517178259761\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";b:0;s:7:\"options\";a:2:{i:0;a:9:{s:6:\"errors\";a:0:{}s:11:\"max_options\";i:0;s:5:\"label\";s:12:\"General Work\";s:5:\"value\";s:12:\"General Work\";s:4:\"calc\";s:2:\"gw\";s:8:\"selected\";i:1;s:5:\"order\";i:0;s:12:\"settingModel\";a:10:{s:8:\"settings\";b:0;s:15:\"hide_merge_tags\";b:0;s:5:\"error\";b:0;s:4:\"name\";s:7:\"options\";s:4:\"type\";s:15:\"option-repeater\";s:5:\"label\";s:159:\"Options <a href=\"#\" class=\"nf-add-new\">Add New</a> <a href=\"#\" class=\"extra nf-open-import-tooltip\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Import</a>\";s:5:\"width\";s:4:\"full\";s:5:\"group\";s:0:\"\";s:5:\"value\";a:3:{i:0;a:5:{s:5:\"label\";s:3:\"One\";s:5:\"value\";s:3:\"one\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:0;}i:1;a:5:{s:5:\"label\";s:3:\"Two\";s:5:\"value\";s:3:\"two\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:1;}i:2;a:5:{s:5:\"label\";s:5:\"Three\";s:5:\"value\";s:5:\"three\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:2;}}s:7:\"columns\";a:4:{s:5:\"label\";a:2:{s:6:\"header\";s:5:\"Label\";s:7:\"default\";s:0:\"\";}s:5:\"value\";a:2:{s:6:\"header\";s:5:\"Value\";s:7:\"default\";s:0:\"\";}s:4:\"calc\";a:2:{s:6:\"header\";s:10:\"Calc Value\";s:7:\"default\";s:0:\"\";}s:8:\"selected\";a:2:{s:6:\"header\";s:45:\"<span class=\"dashicons dashicons-yes\"></span>\";s:7:\"default\";i:0;}}}s:12:\"manual_value\";b:1;}i:1;a:9:{s:6:\"errors\";a:0:{}s:11:\"max_options\";i:0;s:5:\"label\";s:13:\"Fall Festival\";s:5:\"value\";s:13:\"Fall Festival\";s:4:\"calc\";s:2:\"ff\";s:8:\"selected\";i:1;s:5:\"order\";i:1;s:12:\"settingModel\";a:10:{s:8:\"settings\";b:0;s:15:\"hide_merge_tags\";b:0;s:5:\"error\";b:0;s:4:\"name\";s:7:\"options\";s:4:\"type\";s:15:\"option-repeater\";s:5:\"label\";s:159:\"Options <a href=\"#\" class=\"nf-add-new\">Add New</a> <a href=\"#\" class=\"extra nf-open-import-tooltip\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Import</a>\";s:5:\"width\";s:4:\"full\";s:5:\"group\";s:0:\"\";s:5:\"value\";a:3:{i:0;a:5:{s:5:\"label\";s:3:\"One\";s:5:\"value\";s:3:\"one\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:0;}i:1;a:5:{s:5:\"label\";s:3:\"Two\";s:5:\"value\";s:3:\"two\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:1;}i:2;a:5:{s:5:\"label\";s:5:\"Three\";s:5:\"value\";s:5:\"three\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:2;}}s:7:\"columns\";a:4:{s:5:\"label\";a:2:{s:6:\"header\";s:5:\"Label\";s:7:\"default\";s:0:\"\";}s:5:\"value\";a:2:{s:6:\"header\";s:5:\"Value\";s:7:\"default\";s:0:\"\";}s:4:\"calc\";a:2:{s:6:\"header\";s:10:\"Calc Value\";s:7:\"default\";s:0:\"\";}s:8:\"selected\";a:2:{s:6:\"header\";s:45:\"<span class=\"dashicons dashicons-yes\"></span>\";s:7:\"default\";i:0;}}}s:12:\"manual_value\";b:1;}}s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}s:2:\"id\";s:1:\"7\";}i:3;a:2:{s:8:\"settings\";a:20:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:999;s:4:\"type\";s:6:\"number\";s:5:\"label\";s:5:\"Hours\";s:3:\"key\";s:19:\"hours_1517178318434\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:7:\"default\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:7:\"num_min\";s:1:\"0\";s:7:\"num_max\";s:0:\"\";s:8:\"num_step\";s:1:\"1\";s:14:\"drawerDisabled\";b:0;}s:2:\"id\";s:1:\"8\";}i:4;a:2:{s:8:\"settings\";a:10:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:9999;s:4:\"type\";s:6:\"submit\";s:5:\"label\";s:6:\"Submit\";s:16:\"processing_label\";s:10:\"Processing\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:3:\"key\";s:20:\"submit_1517178338457\";}s:2:\"id\";s:1:\"9\";}}s:7:\"actions\";a:3:{i:0;a:2:{s:8:\"settings\";a:23:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:15:\"Success Message\";s:4:\"type\";s:14:\"successmessage\";s:7:\"message\";s:42:\"Your form has been successfully submitted.\";s:5:\"order\";i:1;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";s:11:\"success_msg\";s:42:\"Your form has been successfully submitted.\";}s:2:\"id\";i:5;}i:1;a:2:{s:8:\"settings\";a:20:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:11:\"Admin Email\";s:4:\"type\";s:5:\"email\";s:5:\"order\";i:2;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";}s:2:\"id\";i:6;}i:2;a:2:{s:8:\"settings\";a:21:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:16:\"Store Submission\";s:4:\"type\";s:4:\"save\";s:5:\"order\";i:3;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";}s:2:\"id\";i:7;}}s:8:\"settings\";a:18:{s:10:\"objectType\";s:12:\"Form Setting\";s:10:\"editActive\";b:0;s:5:\"title\";s:9:\"Add Hours\";s:10:\"show_title\";i:1;s:14:\"clear_complete\";i:1;s:13:\"hide_complete\";i:1;s:17:\"default_label_pos\";s:5:\"above\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:3:\"key\";s:0:\"\";s:10:\"add_submit\";i:1;s:8:\"currency\";s:0:\"\";s:18:\"unique_field_error\";s:50:\"A form with this value has already been submitted.\";s:9:\"logged_in\";b:0;s:17:\"not_logged_in_msg\";s:0:\"\";s:13:\"sub_limit_msg\";s:42:\"The form has reached its submission limit.\";s:12:\"calculations\";a:0:{}s:15:\"formContentData\";a:5:{i:0;s:28:\"date_performed_1517178228230\";i:1;s:22:\"activity_1517178202399\";i:2;s:21:\"project_1517178259761\";i:3;s:19:\"hours_1517178318434\";i:4;s:20:\"submit_1517178338457\";}}s:14:\"deleted_fields\";a:0:{}s:15:\"deleted_actions\";a:0:{}}', 'yes'),
(950, 'xyz_credit_link', '0', 'yes'),
(952, 'xyz_ips_premium_version_ads', '1', 'yes'),
(953, 'xyz_ips_auto_insert', '1', 'yes'),
(199, 'cfdb7_view_install_date', '2018-01-28 22:59:55', 'yes'),
(204, 'rewrite_rules', 'a:172:{s:9:\"forums/?$\";s:25:\"index.php?post_type=forum\";s:39:\"forums/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=forum&feed=$matches[1]\";s:34:\"forums/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=forum&feed=$matches[1]\";s:26:\"forums/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=forum&paged=$matches[1]\";s:9:\"topics/?$\";s:25:\"index.php?post_type=topic\";s:39:\"topics/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=topic&feed=$matches[1]\";s:34:\"topics/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=topic&feed=$matches[1]\";s:26:\"topics/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=topic&paged=$matches[1]\";s:28:\"forums/forum/([^/]+)/edit/?$\";s:34:\"index.php?forum=$matches[1]&edit=1\";s:28:\"forums/topic/([^/]+)/edit/?$\";s:34:\"index.php?topic=$matches[1]&edit=1\";s:28:\"forums/reply/([^/]+)/edit/?$\";s:34:\"index.php?reply=$matches[1]&edit=1\";s:32:\"forums/topic-tag/([^/]+)/edit/?$\";s:38:\"index.php?topic-tag=$matches[1]&edit=1\";s:47:\"forums/user/([^/]+)/topics/page/?([0-9]{1,})/?$\";s:59:\"index.php?bbp_user=$matches[1]&bbp_tops=1&paged=$matches[2]\";s:48:\"forums/user/([^/]+)/replies/page/?([0-9]{1,})/?$\";s:59:\"index.php?bbp_user=$matches[1]&bbp_reps=1&paged=$matches[2]\";s:50:\"forums/user/([^/]+)/favorites/page/?([0-9]{1,})/?$\";s:59:\"index.php?bbp_user=$matches[1]&bbp_favs=1&paged=$matches[2]\";s:54:\"forums/user/([^/]+)/subscriptions/page/?([0-9]{1,})/?$\";s:59:\"index.php?bbp_user=$matches[1]&bbp_subs=1&paged=$matches[2]\";s:29:\"forums/user/([^/]+)/topics/?$\";s:41:\"index.php?bbp_user=$matches[1]&bbp_tops=1\";s:30:\"forums/user/([^/]+)/replies/?$\";s:41:\"index.php?bbp_user=$matches[1]&bbp_reps=1\";s:32:\"forums/user/([^/]+)/favorites/?$\";s:41:\"index.php?bbp_user=$matches[1]&bbp_favs=1\";s:36:\"forums/user/([^/]+)/subscriptions/?$\";s:41:\"index.php?bbp_user=$matches[1]&bbp_subs=1\";s:27:\"forums/user/([^/]+)/edit/?$\";s:37:\"index.php?bbp_user=$matches[1]&edit=1\";s:22:\"forums/user/([^/]+)/?$\";s:30:\"index.php?bbp_user=$matches[1]\";s:40:\"forums/view/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?bbp_view=$matches[1]&paged=$matches[2]\";s:27:\"forums/view/([^/]+)/feed/?$\";s:47:\"index.php?bbp_view=$matches[1]&feed=$matches[2]\";s:22:\"forums/view/([^/]+)/?$\";s:30:\"index.php?bbp_view=$matches[1]\";s:34:\"forums/search/page/?([0-9]{1,})/?$\";s:27:\"index.php?paged=$matches[1]\";s:16:\"forums/search/?$\";s:20:\"index.php?bbp_search\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:38:\"forums/forum/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\"forums/forum/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\"forums/forum/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"forums/forum/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"forums/forum/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:44:\"forums/forum/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"forums/forum/(.+?)/embed/?$\";s:38:\"index.php?forum=$matches[1]&embed=true\";s:31:\"forums/forum/(.+?)/trackback/?$\";s:32:\"index.php?forum=$matches[1]&tb=1\";s:51:\"forums/forum/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?forum=$matches[1]&feed=$matches[2]\";s:46:\"forums/forum/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?forum=$matches[1]&feed=$matches[2]\";s:39:\"forums/forum/(.+?)/page/?([0-9]{1,})/?$\";s:45:\"index.php?forum=$matches[1]&paged=$matches[2]\";s:46:\"forums/forum/(.+?)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?forum=$matches[1]&cpage=$matches[2]\";s:35:\"forums/forum/(.+?)(?:/([0-9]+))?/?$\";s:44:\"index.php?forum=$matches[1]&page=$matches[2]\";s:40:\"forums/topic/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"forums/topic/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"forums/topic/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"forums/topic/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"forums/topic/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"forums/topic/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"forums/topic/([^/]+)/embed/?$\";s:38:\"index.php?topic=$matches[1]&embed=true\";s:33:\"forums/topic/([^/]+)/trackback/?$\";s:32:\"index.php?topic=$matches[1]&tb=1\";s:53:\"forums/topic/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?topic=$matches[1]&feed=$matches[2]\";s:48:\"forums/topic/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?topic=$matches[1]&feed=$matches[2]\";s:41:\"forums/topic/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?topic=$matches[1]&paged=$matches[2]\";s:48:\"forums/topic/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?topic=$matches[1]&cpage=$matches[2]\";s:37:\"forums/topic/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?topic=$matches[1]&page=$matches[2]\";s:29:\"forums/topic/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"forums/topic/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"forums/topic/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"forums/topic/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"forums/topic/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"forums/topic/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"forums/reply/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"forums/reply/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"forums/reply/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"forums/reply/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"forums/reply/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"forums/reply/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"forums/reply/([^/]+)/embed/?$\";s:38:\"index.php?reply=$matches[1]&embed=true\";s:33:\"forums/reply/([^/]+)/trackback/?$\";s:32:\"index.php?reply=$matches[1]&tb=1\";s:41:\"forums/reply/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?reply=$matches[1]&paged=$matches[2]\";s:48:\"forums/reply/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?reply=$matches[1]&cpage=$matches[2]\";s:37:\"forums/reply/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?reply=$matches[1]&page=$matches[2]\";s:29:\"forums/reply/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"forums/reply/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"forums/reply/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"forums/reply/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"forums/reply/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"forums/reply/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:57:\"forums/topic-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?topic-tag=$matches[1]&feed=$matches[2]\";s:52:\"forums/topic-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?topic-tag=$matches[1]&feed=$matches[2]\";s:33:\"forums/topic-tag/([^/]+)/embed/?$\";s:42:\"index.php?topic-tag=$matches[1]&embed=true\";s:45:\"forums/topic-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?topic-tag=$matches[1]&paged=$matches[2]\";s:27:\"forums/topic-tag/([^/]+)/?$\";s:31:\"index.php?topic-tag=$matches[1]\";s:42:\"forums/search/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?bbp_search=$matches[1]&paged=$matches[2]\";s:24:\"forums/search/([^/]+)/?$\";s:32:\"index.php?bbp_search=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(180, 'swpm-messages', 'a:0:{}', 'yes'),
(181, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(190, 'ccf_db_version', '7.1', 'yes'),
(191, 'widget_custom-contact-forms', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(192, 'ccf_upgraded_forms', 'a:0:{}', 'yes'),
(292, 'pdb-option_version', '11.2', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1128, 'pdb-default_options', 'a:89:{s:21:\"image_upload_location\";s:41:\"wp-content/uploads/participants-database/\";s:18:\"image_upload_limit\";s:3:\"100\";s:18:\"allowed_file_types\";s:58:\"txt,pdf,mp3,mp4a,ogg,doc,docx,odt,rtf,zip,jpg,jpeg,gif,png\";s:13:\"default_image\";s:57:\"/wp-content/plugins/participants-database/ui/no-image.png\";s:10:\"image_link\";i:0;s:11:\"file_delete\";i:0;s:10:\"allow_tags\";i:0;s:10:\"make_links\";i:0;s:13:\"email_protect\";i:0;s:19:\"empty_field_message\";s:25:\"The %s field is required.\";s:21:\"invalid_field_message\";s:37:\"The %s field appears to be incorrect.\";s:25:\"nonmatching_field_message\";s:37:\"The %s field must match the %s field.\";s:21:\"captcha_field_message\";s:33:\"Pleast try the %s question again.\";s:17:\"field_error_style\";s:21:\"border: 1px solid red\";s:20:\"mark_required_fields\";i:0;s:21:\"required_field_marker\";s:29:\"%s<span class=\"reqd\">*</span>\";s:18:\"signup_button_text\";s:7:\"Sign Up\";s:18:\"signup_thanks_page\";s:4:\"none\";s:30:\"signup_show_group_descriptions\";i:0;s:12:\"unique_field\";s:5:\"email\";s:12:\"unique_email\";i:1;s:23:\"duplicate_field_message\";s:60:\"A record with that %s already exists. Please choose another.\";s:25:\"send_signup_receipt_email\";i:1;s:20:\"receipt_from_address\";s:20:\"ehsantos54@gmail.com\";s:17:\"receipt_from_name\";s:19:\"Volunteer Test Site\";s:28:\"signup_receipt_email_subject\";s:44:\"You\'ve just signed up on Volunteer Test Site\";s:25:\"signup_receipt_email_body\";s:254:\"<p>Thank you, [first_name], for signing up with Volunteer Test Site.</p><p>You may complete your registration with additional information or update your information by visiting this private link at any time: <a href=\"[record_link]\">[record_link]</a>.</p>\";s:13:\"signup_thanks\";s:237:\"<p>Thank you, [first_name] for signing up!</p><p>You will receive an email acknowledgement shortly. You may complete your registration with additional information or update your information by visiting the link provided in the email.</p>\";s:24:\"send_signup_notify_email\";i:1;s:29:\"email_signup_notify_addresses\";s:20:\"ehsantos54@gmail.com\";s:27:\"email_signup_notify_subject\";s:33:\"New signup on Volunteer Test Site\";s:24:\"email_signup_notify_body\";s:196:\"<p>A new signup has been submitted</p><ul><li>Name: [first_name] [last_name]</li><li>Email: [email]</li></ul><p>Edit this new record here: <a href=\"[admin_record_link]\">[admin_record_link]</a></p>\";s:17:\"registration_page\";s:0:\"\";s:23:\"show_group_descriptions\";i:0;s:18:\"save_changes_label\";s:17:\"Save Your Changes\";s:19:\"save_changes_button\";s:4:\"Save\";s:22:\"record_updated_message\";s:33:\"Your information has been updated\";s:23:\"no_record_error_message\";s:20:\"No record was found.\";s:22:\"no_record_use_template\";i:0;s:31:\"send_record_update_notify_email\";i:0;s:27:\"record_update_email_subject\";s:53:\"A record has just been updated on Volunteer Test Site\";s:24:\"record_update_email_body\";s:269:\"<p>The following record was updated on [date]:</p><ul><li>Name: [first_name] [last_name]</li><li>Address: [address]</li><li>[city], [state], [country]</li><li>Phone: [phone]</li><li>Email: [email]</li></ul><p>Edit this record <a href=\"[admin_record_link]\">here.</a></p>\";s:10:\"list_limit\";i:10;s:24:\"single_record_link_field\";s:0:\"\";s:18:\"single_record_page\";s:0:\"\";s:18:\"no_records_message\";s:16:\"No Records Found\";s:10:\"show_count\";i:0;s:14:\"count_template\";s:48:\"Total Records Found: %1$s, showing %2$s per page\";s:17:\"list_default_sort\";s:12:\"date_updated\";s:23:\"list_default_sort_order\";s:4:\"desc\";s:12:\"empty_search\";i:0;s:18:\"show_retrieve_link\";i:0;s:18:\"retrieve_link_text\";s:63:\"Forget your private link? Click here to have it emailed to you.\";s:19:\"link_retrieval_page\";s:4:\"none\";s:24:\"retrieve_link_identifier\";s:5:\"email\";s:15:\"id_field_prompt\";s:58:\"Type in your %s, your private link will be emailed to you.\";s:27:\"retrieve_link_email_subject\";s:48:\"Here is your private link on Volunteer Test Site\";s:24:\"retrieve_link_email_body\";s:120:\"<p>Here is the private link you requested from Volunteer Test Site:</p><p><a href=\"[record_link]\">[record_link]</a>.</p>\";s:31:\"send_retrieve_link_notify_email\";i:0;s:28:\"retrieve_link_notify_subject\";s:61:\"A Lost Private Link has been requested on Volunteer Test Site\";s:25:\"retrieve_link_notify_body\";s:120:\"<p>A lost private link has been requested by:</p><ul><li>Name: [first_name] [last_name]</li><li>Email: [email]</li></ul>\";s:24:\"identifier_field_message\";s:42:\"A record matching that %s cannot be found.\";s:14:\"use_plugin_css\";i:1;s:16:\"rich_text_editor\";i:1;s:14:\"enable_wpautop\";s:11:\"the_content\";s:16:\"strip_linebreaks\";i:0;s:28:\"use_pagination_scroll_anchor\";i:1;s:27:\"primary_email_address_field\";s:5:\"email\";s:10:\"html_email\";i:1;s:12:\"strict_dates\";i:0;s:17:\"input_date_format\";s:6:\"F j, Y\";s:9:\"show_time\";i:0;s:13:\"strict_search\";i:0;s:11:\"ajax_search\";i:1;s:16:\"use_php_sessions\";i:0;s:11:\"cookie_name\";s:14:\"pdb_wp_session\";s:26:\"disable_live_notifications\";i:0;s:27:\"files_use_content_base_path\";i:0;s:27:\"allow_record_timestamp_edit\";i:0;s:18:\"admin_default_sort\";s:12:\"date_updated\";s:24:\"admin_default_sort_order\";s:4:\"desc\";s:16:\"admin_thumbnails\";i:0;s:18:\"admin_horiz_scroll\";i:0;s:22:\"record_edit_capability\";s:17:\"edit_others_posts\";s:23:\"plugin_admin_capability\";s:14:\"manage_options\";s:25:\"editor_allowed_csv_export\";s:1:\"0\";s:10:\"custom_css\";s:0:\"\";s:9:\"print_css\";s:88:\"/* this prevents the search controls from printing */\r.pdb-searchform {\r	display:none;\r}\";s:16:\"custom_admin_css\";s:0:\"\";}', 'yes'),
(7163, '_transient_timeout_pdb-live_notification_greeting', '1518273429', 'no'),
(7164, '_transient_pdb-live_notification_greeting', '{\"id\":2199,\"date\":\"2016-08-13T11:32:45\",\"date_gmt\":\"2016-08-13T21:32:45\",\"guid\":{\"rendered\":\"https:\\/\\/xnau.com\\/?post_type=live_notification&#038;p=2199\"},\"modified\":\"2016-12-06T20:27:30\",\"modified_gmt\":\"2016-12-07T06:27:30\",\"slug\":\"list-page-banner\",\"status\":\"publish\",\"type\":\"live_notification\",\"link\":\"https:\\/\\/xnau.com\\/?live_notification=list-page-banner\",\"title\":{\"rendered\":\"Greeting (List Page Banner)\"},\"content\":{\"rendered\":\"<div class=\\\"top_notification_banner live_notification-cpt\\\"><img class=\\\"size-medium wp-image-1623 aligncenter\\\" style=\\\"width: 100%; height: auto;\\\" src=\\\"https:\\/\\/xnau.com\\/images\\/branding\\/participants-database\\/plain-banner-600x122.jpg\\\" alt=\\\"By Tukulti65 - Own work, CC BY-SA 4.0, https:\\/\\/commons.wikimedia.org\\/w\\/index.php?curid=47436569\\\" \\/><\\/div>\\n<p><a href=\\\"https:\\/\\/xnau.com\\/shop\\\"><span style=\\\"color: #993300;\\\">Now Available&#8230;<\\/span><\\/a> add-ons and UI enhancements for Participants Database at the <a href=\\\"https:\\/\\/xnau.com\\/shop\\\">xnau.com store<\\/a>\\u2026<\\/p>\\n\",\"protected\":false},\"featured_media\":0,\"template\":\"\",\"_links\":{\"self\":[{\"href\":\"https:\\/\\/xnau.com\\/wp-json\\/wp\\/v2\\/live_notification\\/2199\"}],\"collection\":[{\"href\":\"https:\\/\\/xnau.com\\/wp-json\\/wp\\/v2\\/live_notification\"}],\"about\":[{\"href\":\"https:\\/\\/xnau.com\\/wp-json\\/wp\\/v2\\/types\\/live_notification\"}],\"wp:attachment\":[{\"href\":\"https:\\/\\/xnau.com\\/wp-json\\/wp\\/v2\\/media?parent=2199\"}],\"curies\":[{\"name\":\"wp\",\"href\":\"https:\\/\\/api.w.org\\/{rel}\",\"templated\":true}]}}', 'no'),
(7189, '_wp_session_expires_dd168b13a041573eb21b9f06a4ff76a9', '1518107228', 'no'),
(7212, '_wp_session_dd168b13a041573eb21b9f06a4ff76a9', 'a:3:{s:25:\"pdb-admin-user-settings-1\";O:21:\"Recursive_ArrayAccess\":2:{s:12:\"\0*\0container\";a:1:{s:10:\"list_limit\";s:2:\"10\";}s:8:\"\0*\0dirty\";b:1;}s:23:\"pdb-admin_list_filter-1\";O:21:\"Recursive_ArrayAccess\":2:{s:12:\"\0*\0container\";a:4:{s:6:\"search\";O:21:\"Recursive_ArrayAccess\":2:{s:12:\"\0*\0container\";a:1:{i:0;O:21:\"Recursive_ArrayAccess\":2:{s:12:\"\0*\0container\";a:4:{s:12:\"search_field\";s:4:\"none\";s:5:\"value\";s:0:\"\";s:8:\"operator\";s:4:\"LIKE\";s:5:\"logic\";s:3:\"AND\";}s:8:\"\0*\0dirty\";b:1;}}s:8:\"\0*\0dirty\";b:1;}s:6:\"sortBy\";s:12:\"date_updated\";s:7:\"ascdesc\";s:4:\"desc\";s:17:\"list_filter_count\";i:1;}s:8:\"\0*\0dirty\";b:1;}s:22:\"pdb-admin_list_query-1\";s:70:\"SELECT * FROM wp_participants_database p  ORDER BY p.date_updated desc\";}', 'no'),
(7186, '_wp_session_3af2b7688cdd5538e784392284625b7d', 'a:0:{}', 'no'),
(7187, '_wp_session_expires_3af2b7688cdd5538e784392284625b7d', '1518107228', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_participants_database`
--

DROP TABLE IF EXISTS `wp_participants_database`;
CREATE TABLE IF NOT EXISTS `wp_participants_database` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `private_id` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` text COLLATE utf8_unicode_ci,
  `last_name` text COLLATE utf8_unicode_ci,
  `email` text COLLATE utf8_unicode_ci,
  `date_performed` bigint(20) DEFAULT NULL,
  `activity` tinytext COLLATE utf8_unicode_ci,
  `project` text COLLATE utf8_unicode_ci,
  `section` text COLLATE utf8_unicode_ci,
  `hours` decimal(4,2) DEFAULT NULL,
  `user_login` text COLLATE utf8_unicode_ci,
  `edit_link` tinytext COLLATE utf8_unicode_ci,
  `approved` text COLLATE utf8_unicode_ci,
  `interests` text COLLATE utf8_unicode_ci,
  `photo` text COLLATE utf8_unicode_ci,
  `website` text COLLATE utf8_unicode_ci,
  `mailing_list` text COLLATE utf8_unicode_ci,
  `date_recorded` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` timestamp NULL DEFAULT NULL,
  `last_accessed` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wp_participants_database`
--

INSERT INTO `wp_participants_database` (`id`, `private_id`, `first_name`, `last_name`, `email`, `date_performed`, `activity`, `project`, `section`, `hours`, `user_login`, `edit_link`, `approved`, `interests`, `photo`, `website`, `mailing_list`, `date_recorded`, `date_updated`, `last_accessed`) VALUES
(55, 'MMEQ4', 'John', 'Doe', 'jdoe@email.com', 1483315200, 'Cleaning camp', 'General Work', 'Hardman Farm', '3.00', 'jdoe', 'Edit', 'no', '', '', '', NULL, '2018-02-05 05:30:38', '2018-02-05 06:32:55', '2018-02-06 04:48:45'),
(56, 'MT6LB', 'John', 'Doe', 'jdoe@email.com', 1509840000, 'Decorating Camp', 'Fall Festival', 'Smithgall Woods', '3.00', 'jdoe', 'Edit', 'no', '', '', '', NULL, '2018-02-05 05:31:33', '2018-02-05 06:31:18', '2018-02-05 12:28:57'),
(57, '556GG', 'John', 'Doe', 'jdoe@email.com', 1506902400, 'Washing vehicles', 'Fall Festival', 'Smithgall Woods', '2.00', 'jdoe', 'Edit', 'no', 'a:3:{i:1;s:6:\"sports\";i:2;s:6:\"crafts\";i:3;s:8:\"outdoors\";}', '', '', NULL, '2018-02-05 06:16:55', '2018-02-05 10:16:01', '2018-02-06 05:07:49'),
(58, '0Z68R', 'Robert', 'Smith', 'rsmith@email.com', 1516838400, 'Building fences', 'General Work', 'Hardman Farm', '5.00', 'rsmith', 'Edit', 'no', 'a:2:{i:1;s:6:\"crafts\";i:2;s:5:\"music\";}', '', '', NULL, '2018-02-05 12:27:09', '2018-02-05 12:27:52', '2018-02-06 04:16:10'),
(59, '3LJLF', 'John', 'Doe', 'jdoe@email.com1', 1517529600, 'Painting Fences', 'General Work', 'Hardman Farm', '3.00', 'jdoe', 'Edit', 'no', 'a:2:{i:1;s:6:\"crafts\";i:2;s:8:\"outdoors\";}', NULL, NULL, NULL, '2018-02-06 04:27:21', '2018-02-06 04:27:21', '2018-02-06 05:11:30'),
(67, 'XXSLL', 'John', 'Doe', 'jdoe@email.com1', 1485993600, 'Washing buses', 'General Work', 'Hardman Farm', '2.00', 'jdoe', 'Edit', 'no', 'a:2:{i:1;s:6:\"sports\";i:2;s:6:\"crafts\";}', NULL, NULL, NULL, '2018-02-06 05:12:39', '2018-02-06 05:12:39', '2018-02-06 05:45:13'),
(68, 'M4QMQ', 'John', 'Doe', 'jdoe@email.com', 1493856000, 'Planting bushes', 'General Work', 'Hardman Farm', '1.00', 'jdoe', 'Edit', 'no', 'a:1:{i:1;s:6:\"crafts\";}', '', '', NULL, '2018-02-06 05:46:49', '2018-02-06 05:48:19', '2018-02-08 14:44:05');

-- --------------------------------------------------------

--
-- Table structure for table `wp_participants_database_fields`
--

DROP TABLE IF EXISTS `wp_participants_database_fields`;
CREATE TABLE IF NOT EXISTS `wp_participants_database_fields` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `order` int(3) NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `default` tinytext COLLATE utf8_unicode_ci,
  `group` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `help_text` text COLLATE utf8_unicode_ci,
  `form_element` tinytext COLLATE utf8_unicode_ci,
  `values` longtext COLLATE utf8_unicode_ci,
  `validation` tinytext COLLATE utf8_unicode_ci,
  `display_column` int(3) DEFAULT '0',
  `admin_column` int(3) DEFAULT '0',
  `sortable` tinyint(1) DEFAULT '0',
  `CSV` tinyint(1) DEFAULT '0',
  `persistent` tinyint(1) DEFAULT '0',
  `signup` tinyint(1) DEFAULT '0',
  `readonly` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `order` (`order`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wp_participants_database_fields`
--

INSERT INTO `wp_participants_database_fields` (`id`, `order`, `name`, `title`, `default`, `group`, `help_text`, `form_element`, `values`, `validation`, `display_column`, `admin_column`, `sortable`, `CSV`, `persistent`, `signup`, `readonly`) VALUES
(1, 0, 'first_name', 'First Name', 'current_user->user_firstname', 'main', '', 'hidden', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 0, 0, 1, 1, 1, 1, 0),
(2, 1, 'last_name', 'Last Name', 'current_user->user_lastname', 'main', '', 'hidden', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 0, 2, 1, 1, 1, 1, 0),
(31, 6, 'project', 'Project', '', 'main', '', 'dropdown', 'a:3:{s:12:\"General Work\";s:12:\"General Work\";s:13:\"Fall Festival\";s:13:\"Fall Festival\";s:18:\"Spring Celebration\";s:18:\"Spring Celebration\";}', 'yes', 7, 7, 0, 1, 1, 1, 0),
(9, 3, 'email', 'Email', 'current_user->user_email', 'main', '', 'hidden', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 0, 0, 0, 1, 1, 1, 1),
(20, 2, 'user_login', 'User Login', 'current_user->user_login', 'main', '', 'hidden', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 0, 3, 0, 1, 1, 1, 0),
(21, 4, 'date_performed', 'Date Performed', '', 'main', '', 'date', 'a:1:{s:0:\"\";s:0:\"\";}', 'yes', 5, 5, 1, 1, 1, 1, 0),
(11, 10, 'photo', 'Photo', NULL, 'personal', 'Upload a photo of yourself. 300 pixels maximum width or height.', 'image-upload', NULL, 'no', 0, 0, 0, 0, 0, 0, 0),
(12, 11, 'website', 'Website, Blog or Social Media Link', NULL, 'personal', 'Put the URL in the left box and the link text that will be shown on the right', 'link', NULL, 'no', 0, 0, 0, 0, 0, 0, 0),
(13, 12, 'interests', 'Interests or Hobbies', '', 'personal', '', 'multi-select-other', 'a:7:{s:6:\"Sports\";s:6:\"sports\";s:11:\"Photography\";s:11:\"photography\";s:10:\"Art/Crafts\";s:6:\"crafts\";s:8:\"Outdoors\";s:8:\"outdoors\";s:4:\"Yoga\";s:4:\"yoga\";s:5:\"Music\";s:5:\"music\";s:7:\"Cuisine\";s:7:\"cuisine\";}', 'no', 0, 0, 0, 0, 0, 1, 0),
(14, 13, 'approved', 'Approved', 'no', 'admin', NULL, 'checkbox', 'a:2:{i:0;s:3:\"yes\";i:1;s:2:\"no\";}', 'no', 0, 0, 1, 0, 0, 0, 0),
(15, 14, 'id', 'Record ID', NULL, 'internal', NULL, 'text-line', NULL, 'no', 0, 80, 0, 1, 0, 1, 1),
(16, 15, 'private_id', 'Private ID', 'RPNE2', 'internal', NULL, 'text', NULL, 'no', 0, 90, 0, 0, 0, 1, 1),
(17, 16, 'date_recorded', 'Date Recorded', NULL, 'internal', NULL, 'timestamp', NULL, 'no', 0, 100, 1, 0, 0, 0, 1),
(18, 17, 'date_updated', 'Date Updated', NULL, 'internal', NULL, 'timestamp', NULL, 'no', 0, 0, 1, 0, 0, 0, 1),
(19, 18, 'last_accessed', 'Last Accessed', NULL, 'internal', NULL, 'timestamp', NULL, 'no', 0, 0, 1, 0, 0, 0, 1),
(23, 9, 'edit_link', 'Edit Link', 'Edit', 'main', '', 'text-line', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 10, 0, 0, 0, 0, 0, 1),
(25, 5, 'activity', 'Activity', '', 'main', '', 'text-line', 'a:1:{s:0:\"\";s:0:\"\";}', 'no', 6, 6, 0, 1, 1, 1, 0),
(32, 7, 'section', 'Section', '', 'main', '', 'dropdown', 'a:2:{s:12:\"Hardman Farm\";s:12:\"Hardman Farm\";s:15:\"Smithgall Woods\";s:15:\"Smithgall Woods\";}', 'yes', 8, 8, 0, 1, 1, 1, 0),
(30, 8, 'hours', 'Hours', '', 'main', '', 'numeric', 'a:3:{s:3:\"min\";s:2:\"-0\";s:3:\"max\";s:3:\"100\";s:4:\"step\";s:4:\"0.25\";}', 'yes', 9, 9, 0, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_participants_database_groups`
--

DROP TABLE IF EXISTS `wp_participants_database_groups`;
CREATE TABLE IF NOT EXISTS `wp_participants_database_groups` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `order` int(3) NOT NULL DEFAULT '0',
  `display` tinyint(1) DEFAULT '1',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wp_participants_database_groups`
--

INSERT INTO `wp_participants_database_groups` (`id`, `order`, `display`, `admin`, `title`, `name`, `description`) VALUES
(1, 1, 1, 0, 'Volunteer Info', 'main', ''),
(2, 2, 1, 0, 'Personal Info', 'personal', ''),
(3, 3, 0, 0, 'Administrative Info', 'admin', ''),
(4, 4, 0, 0, 'Record Info', 'internal', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_wp_trash_meta_status', 'publish'),
(3, 4, '_wp_trash_meta_time', '1517178356'),
(4, 4, '_wp_desired_post_slug', 'membership-join'),
(5, 10, '_edit_last', '1'),
(6, 10, '_edit_lock', '1517650634:1'),
(7, 12, '_edit_last', '1'),
(8, 12, '_edit_lock', '1517828194:1'),
(9, 14, '_edit_lock', '1517179165:1'),
(10, 5, '_edit_lock', '1517727121:1'),
(173, 48, '_edit_lock', '1517645368:1'),
(186, 54, '_edit_lock', '1517640489:1'),
(172, 34, 'php_everywhere_code', '<?php\r\nif($instance==\"1\")\r\n{\r\n$current_user = wp_get_current_user();\r\necho do_shortcode(\'[pdb_list template=edit-link filter=\"user_login=\' . $current_user->user_login . \'\"]\');\r\n}\r\nif($instance==\"2\")\r\n{\r\necho do_shortcode(\'[pdb_total fields=\"hours” filter=\"user_login=\' . $current_user->user_login . \'\"]\');\r\n}\r\n?>\r\n'),
(171, 34, '_wp_page_template', 'default'),
(29, 6, '_edit_lock', '1517183870:1'),
(20, 16, '_menu_item_type', 'post_type'),
(21, 16, '_menu_item_menu_item_parent', '0'),
(22, 16, '_menu_item_object_id', '10'),
(23, 16, '_menu_item_object', 'page'),
(24, 16, '_menu_item_target', ''),
(25, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(26, 16, '_menu_item_xfn', ''),
(27, 16, '_menu_item_url', ''),
(30, 5, '_edit_last', '1'),
(31, 7, '_edit_lock', '1517727192:1'),
(32, 7, '_edit_last', '1'),
(33, 8, '_edit_lock', '1517179030:1'),
(34, 14, '_wp_trash_meta_status', 'publish'),
(35, 14, '_wp_trash_meta_time', '1517179165'),
(36, 19, '_field_5', '2018-01-11T00:00:00-05:00'),
(37, 19, '_field_6', 'Cleaning'),
(38, 19, '_field_7', 'Fall Festival'),
(39, 19, '_field_8', '5'),
(40, 19, '_form_id', '2'),
(41, 19, '_seq_num', '1'),
(102, 26, '_mail', 'a:8:{s:7:\"subject\";s:36:\"Volunteer Test Site \"[your-subject]\"\";s:6:\"sender\";s:34:\"[your-name] <ehsantos54@gmail.com>\";s:4:\"body\";s:186:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\";s:9:\"recipient\";s:20:\"ehsantos54@gmail.com\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(101, 26, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]'),
(56, 22, 'ccf_attached_fields', 'a:2:{i:0;i:24;i:1;i:25;}'),
(57, 22, 'ccf_form_notifications', 'a:0:{}'),
(58, 22, 'ccf_form_post_field_mappings', 'a:0:{}'),
(59, 22, 'ccf_form_buttonText', 'Submit Form'),
(60, 22, 'ccf_form_buttonClass', ''),
(61, 22, 'ccf_form_description', ''),
(62, 22, 'ccf_form_completion_action_type', 'text'),
(63, 22, 'ccf_form_completion_message', ''),
(64, 22, 'ccf_form_completion_redirect_url', ''),
(65, 22, 'ccf_form_pause', ''),
(66, 22, 'ccf_form_hide_title', ''),
(67, 22, 'ccf_form_require_logged_in', ''),
(68, 22, 'ccf_form_theme', ''),
(69, 22, 'ccf_form_post_creation', ''),
(70, 22, 'ccf_form_post_creation_type', 'post'),
(71, 22, 'ccf_form_post_creation_status', 'draft'),
(72, 22, 'ccf_form_pause_message', 'This form is paused right now. Check back later!'),
(73, 22, '_edit_lock', '1517180181:1'),
(74, 24, 'ccf_field_type', 'date'),
(75, 24, 'ccf_field_slug', 'date-2'),
(76, 24, 'ccf_field_placeholder', ''),
(77, 24, 'ccf_field_className', ''),
(78, 24, 'ccf_field_label', 'Date'),
(79, 24, 'ccf_field_description', ''),
(80, 24, 'ccf_field_value', ''),
(81, 24, 'ccf_field_required', ''),
(82, 24, 'ccf_field_showDate', '1'),
(83, 24, 'ccf_field_showTime', ''),
(84, 24, 'ccf_field_dateFormat', 'mm/dd/yyyy'),
(85, 24, 'ccf_field_conditionalsEnabled', ''),
(86, 24, 'ccf_field_conditionalType', 'show'),
(87, 24, 'ccf_field_conditionalFieldsRequired', 'all'),
(88, 24, 'ccf_attached_conditionals', 'a:0:{}'),
(89, 25, 'ccf_field_type', 'single-line-text'),
(90, 25, 'ccf_field_slug', 'single-line-text-1'),
(91, 25, 'ccf_field_placeholder', ''),
(92, 25, 'ccf_field_className', ''),
(93, 25, 'ccf_field_label', 'Activity'),
(94, 25, 'ccf_field_description', ''),
(95, 25, 'ccf_field_value', ''),
(96, 25, 'ccf_field_required', '1'),
(97, 25, 'ccf_field_conditionalsEnabled', ''),
(98, 25, 'ccf_field_conditionalType', 'show'),
(99, 25, 'ccf_field_conditionalFieldsRequired', 'all'),
(100, 25, 'ccf_attached_conditionals', 'a:0:{}'),
(103, 26, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:36:\"Volunteer Test Site \"[your-subject]\"\";s:6:\"sender\";s:42:\"Volunteer Test Site <ehsantos54@gmail.com>\";s:4:\"body\";s:128:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:30:\"Reply-To: ehsantos54@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(104, 26, '_messages', 'a:8:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";}'),
(105, 26, '_additional_settings', NULL),
(106, 26, '_locale', 'en_US'),
(121, 28, '_additional_settings', ''),
(122, 28, '_locale', 'en_US'),
(167, 41, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(166, 41, '_menu_item_target', ''),
(118, 28, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:36:\"Volunteer Test Site \"[your-subject]\"\";s:6:\"sender\";s:34:\"[your-name] <ehsantos54@gmail.com>\";s:9:\"recipient\";s:20:\"ehsantos54@gmail.com\";s:4:\"body\";s:186:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(119, 28, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:36:\"Volunteer Test Site \"[your-subject]\"\";s:6:\"sender\";s:42:\"Volunteer Test Site <ehsantos54@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:128:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\";s:18:\"additional_headers\";s:30:\"Reply-To: ehsantos54@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(120, 28, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(117, 28, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Date Performed (required)\n    [date* date-916] </label>\n\n<label> Hours (required)\n    [number* number-487] </label>\n\n<label> Project \n    [select menu-282 \"General Work\" \"Fall Festival\"] </label>\n\n[submit \"Send\"]'),
(165, 41, '_menu_item_object', 'page'),
(164, 41, '_menu_item_object_id', '2'),
(163, 41, '_menu_item_menu_item_parent', '0'),
(162, 41, '_menu_item_type', 'post_type'),
(132, 34, '_edit_lock', '1517898358:1'),
(133, 34, '_edit_last', '1'),
(134, 2, '_edit_lock', '1517798443:1'),
(135, 38, '_menu_item_type', 'post_type'),
(136, 38, '_menu_item_menu_item_parent', '0'),
(137, 38, '_menu_item_object_id', '34'),
(138, 38, '_menu_item_object', 'page'),
(139, 38, '_menu_item_target', ''),
(140, 38, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(141, 38, '_menu_item_xfn', ''),
(142, 38, '_menu_item_url', ''),
(169, 41, '_menu_item_url', ''),
(144, 39, '_menu_item_type', 'post_type'),
(145, 39, '_menu_item_menu_item_parent', '0'),
(146, 39, '_menu_item_object_id', '12'),
(147, 39, '_menu_item_object', 'page'),
(148, 39, '_menu_item_target', ''),
(149, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(150, 39, '_menu_item_xfn', ''),
(151, 39, '_menu_item_url', ''),
(174, 48, '_edit_last', '1'),
(153, 40, '_menu_item_type', 'post_type'),
(154, 40, '_menu_item_menu_item_parent', '0'),
(155, 40, '_menu_item_object_id', '7'),
(156, 40, '_menu_item_object', 'page'),
(157, 40, '_menu_item_target', ''),
(158, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(159, 40, '_menu_item_xfn', ''),
(160, 40, '_menu_item_url', ''),
(168, 41, '_menu_item_xfn', ''),
(175, 48, '_wp_page_template', 'default'),
(176, 48, 'php_everywhere_code', '<?php\r\necho do_shortcode(\'[pdb_record record_id=\"\' . Participants_Db::get_record_id_by_term(\'user_login\', $current_user->user_login, true) . \'\"]\');\r\n?>'),
(177, 51, '_menu_item_type', 'post_type'),
(178, 51, '_menu_item_menu_item_parent', '0'),
(179, 51, '_menu_item_object_id', '48'),
(180, 51, '_menu_item_object', 'page'),
(181, 51, '_menu_item_target', ''),
(182, 51, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(183, 51, '_menu_item_xfn', ''),
(184, 51, '_menu_item_url', ''),
(187, 54, '_edit_last', '1'),
(188, 54, '_wp_page_template', 'default'),
(189, 54, 'php_everywhere_code', 'Just put [php_everywhere] where you want the code to be executed.'),
(190, 56, '_menu_item_type', 'post_type'),
(191, 56, '_menu_item_menu_item_parent', '0'),
(192, 56, '_menu_item_object_id', '54'),
(193, 56, '_menu_item_object', 'page'),
(194, 56, '_menu_item_target', ''),
(195, 56, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(196, 56, '_menu_item_xfn', ''),
(197, 56, '_menu_item_url', ''),
(204, 1, '_edit_lock', '1517798816:1'),
(205, 1, '_edit_last', '1'),
(208, 1, 'php_everywhere_code', 'Just put [php_everywhere] where you want the code to be executed.'),
(201, 10, 'php_everywhere_code', 'Just put [php_everywhere] where you want the code to be executed.'),
(202, 12, '_wp_page_template', 'default'),
(203, 12, 'php_everywhere_code', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-01-28 22:18:36', '2018-01-28 22:18:36', 'Welcome to Friends of Smithgall Woods State Park. This is your first post. Edit or delete it, then start writing!', 'Hello Volunteer!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-02-05 02:44:02', '2018-02-05 02:44:02', '', 0, 'http://localhost/myfirstsite/?p=1', 0, 'post', '', 1),
(2, 1, '2018-01-28 22:18:36', '2018-01-28 22:18:36', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/myfirstsite/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-01-28 22:18:36', '2018-01-28 22:18:36', '', 0, 'http://localhost/myfirstsite/?page_id=2', 0, 'page', '', 0),
(146, 1, '2018-02-06 04:20:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-06 04:20:01', '0000-00-00 00:00:00', '', 0, 'http://localhost/myfirstsite/?p=146', 0, 'post', '', 0),
(4, 1, '2018-01-28 22:22:30', '2018-01-28 22:22:30', '<p style=\"color:red;font-weight:bold;\">This page and the content has been automatically generated for you to give you a basic idea of how a \"Join Us\" page should look like. You can customize this page however you like it by editing this page from your WordPress page editor.</p><p style=\"font-weight:bold;\">If you end up changing the URL of this page then make sure to update the URL value in the settings menu of the plugin.</p><p style=\"border-top:1px solid #ccc;padding-top:10px;margin-top:10px;\"></p>\r\n			<strong>Free Membership</strong>\r\n			<br />\r\n			You get unlimited access to free membership content\r\n			<br />\r\n			<em><strong>Price: Free!</strong></em>\r\n			<br /><br />Link the following image to go to the Registration Page if you want your visitors to be able to create a free membership account<br /><br />\r\n			<img title=\"Join Now\" src=\"http://localhost/myfirstsite/wp-content/plugins/simple-membership/images/join-now-button-image.gif\" alt=\"Join Now Button\" width=\"277\" height=\"82\" />\r\n			<p style=\"border-bottom:1px solid #ccc;padding-bottom:10px;margin-bottom:10px;\"></p><p><strong>You can register for a Free Membership or pay for one of the following membership options</strong></p><p style=\"border-top:1px solid #ccc;padding-top:10px;margin-top:10px;\"></p>\r\n			[ ==> Insert Payment Button For Your Paid Membership Levels Here <== ]\r\n			<p style=\"border-bottom:1px solid #ccc;padding-bottom:10px;margin-bottom:10px;\"></p>', 'Join Us', '', 'trash', 'closed', 'closed', '', 'membership-join__trashed', '', '', '2018-01-28 22:25:56', '2018-01-28 22:25:56', '', 0, 'http://localhost/myfirstsite/membership-join/', 0, 'page', '', 0),
(5, 1, '2018-01-28 22:22:30', '2018-01-28 22:22:30', '[swpm_registration_form]', 'Registration', '', 'publish', 'closed', 'closed', '', 'membership-registration', '', '', '2018-01-28 22:37:04', '2018-01-28 22:37:04', '', 0, 'http://localhost/myfirstsite/membership-join/membership-registration/', 0, 'page', '', 0),
(6, 1, '2018-01-28 22:22:30', '2018-01-28 22:22:30', '[swpm_login_form]', 'Member Login', '', 'publish', 'closed', 'closed', '', 'membership-login', '', '', '2018-01-28 22:22:30', '2018-01-28 22:22:30', '', 0, 'http://localhost/myfirstsite/membership-login/', 0, 'page', '', 0),
(7, 1, '2018-01-28 22:22:30', '2018-01-28 22:22:30', '[swpm_profile_form]', 'Profile', '', 'publish', 'closed', 'closed', '', 'membership-profile', '', '', '2018-01-28 22:38:03', '2018-01-28 22:38:03', '', 6, 'http://localhost/myfirstsite/membership-login/membership-profile/', 0, 'page', '', 0),
(8, 1, '2018-01-28 22:22:30', '2018-01-28 22:22:30', '[swpm_reset_form]', 'Password Reset', '', 'publish', 'closed', 'closed', '', 'password-reset', '', '', '2018-01-28 22:22:30', '2018-01-28 22:22:30', '', 6, 'http://localhost/myfirstsite/membership-login/password-reset/', 0, 'page', '', 0),
(9, 1, '2018-01-28 22:25:56', '2018-01-28 22:25:56', '<p style=\"color:red;font-weight:bold;\">This page and the content has been automatically generated for you to give you a basic idea of how a \"Join Us\" page should look like. You can customize this page however you like it by editing this page from your WordPress page editor.</p><p style=\"font-weight:bold;\">If you end up changing the URL of this page then make sure to update the URL value in the settings menu of the plugin.</p><p style=\"border-top:1px solid #ccc;padding-top:10px;margin-top:10px;\"></p>\r\n			<strong>Free Membership</strong>\r\n			<br />\r\n			You get unlimited access to free membership content\r\n			<br />\r\n			<em><strong>Price: Free!</strong></em>\r\n			<br /><br />Link the following image to go to the Registration Page if you want your visitors to be able to create a free membership account<br /><br />\r\n			<img title=\"Join Now\" src=\"http://localhost/myfirstsite/wp-content/plugins/simple-membership/images/join-now-button-image.gif\" alt=\"Join Now Button\" width=\"277\" height=\"82\" />\r\n			<p style=\"border-bottom:1px solid #ccc;padding-bottom:10px;margin-bottom:10px;\"></p><p><strong>You can register for a Free Membership or pay for one of the following membership options</strong></p><p style=\"border-top:1px solid #ccc;padding-top:10px;margin-top:10px;\"></p>\r\n			[ ==> Insert Payment Button For Your Paid Membership Levels Here <== ]\r\n			<p style=\"border-bottom:1px solid #ccc;padding-bottom:10px;margin-bottom:10px;\"></p>', 'Join Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-28 22:25:56', '2018-01-28 22:25:56', '', 4, 'http://localhost/myfirstsite/2018/01/28/4-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-01-28 22:26:12', '2018-01-28 22:26:12', '', 'About Us Friends', '', 'publish', 'closed', 'closed', '', 'about-us-friends', '', '', '2018-01-28 22:26:12', '2018-01-28 22:26:12', '', 0, 'http://localhost/myfirstsite/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-01-28 22:26:12', '2018-01-28 22:26:12', '', 'About Us Friends', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-01-28 22:26:12', '2018-01-28 22:26:12', '', 10, 'http://localhost/myfirstsite/2018/01/28/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-01-28 22:26:35', '2018-01-28 22:26:35', '[pdb_signup]\r\n\r\n[pdb_signup_thanks]', 'Add Volunteer Hours', '', 'publish', 'closed', 'closed', '', 'add-volunteer-hours', '', '', '2018-02-04 14:54:43', '2018-02-04 14:54:43', '', 0, 'http://localhost/myfirstsite/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-01-28 22:26:35', '2018-01-28 22:26:35', '[ninja_form id=2]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-01-28 22:26:35', '2018-01-28 22:26:35', '', 12, 'http://localhost/myfirstsite/2018/01/28/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-01-28 22:39:25', '2018-01-28 22:39:25', '{\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [\n            \"search-2\",\n            \"recent-posts-2\",\n            \"bbp_login_widget-3\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-01-28 22:29:32\"\n    },\n    \"widget_bbp_login_widget[3]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjE1OiJWb2x1bnRlZXIgTG9naW4iO3M6ODoicmVnaXN0ZXIiO3M6NTM6Imh0dHA6Ly9sb2NhbGhvc3QvbXlmaXJzdHNpdGUvbWVtYmVyc2hpcC1yZWdpc3RyYXRpb24vIjtzOjg6Imxvc3RwYXNzIjtzOjYxOiJodHRwOi8vbG9jYWxob3N0L215Zmlyc3RzaXRlL21lbWJlcnNoaXAtbG9naW4vcGFzc3dvcmQtcmVzZXQvIjt9\",\n            \"title\": \"Volunteer Login\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"2d81eaa447fd19a09fb14320b274bc35\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-01-28 22:39:25\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0a802327-d5b2-48b2-a042-0b10c8fd792e', '', '', '2018-01-28 22:39:25', '2018-01-28 22:39:25', '', 0, 'http://localhost/myfirstsite/?p=14', 0, 'customize_changeset', '', 0),
(16, 1, '2018-01-28 22:35:40', '2018-01-28 22:35:40', ' ', '', '', 'publish', 'closed', 'closed', '', '16', '', '', '2018-02-02 12:55:42', '2018-02-02 12:55:42', '', 0, 'http://localhost/myfirstsite/?p=16', 1, 'nav_menu_item', '', 0),
(42, 1, '2018-02-06 06:19:05', '2018-02-06 06:19:05', '[php_everywhere instance=\"1\"]\n[pdb_total fields=\"hours”]\n[pdb_total filter=\"user_login=\'$current_user->user_login . \'\"]\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-autosave-v1', '', '', '2018-02-06 06:19:05', '2018-02-06 06:19:05', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-autosave-v1/', 0, 'revision', '', 0),
(17, 1, '2018-01-28 22:37:04', '2018-01-28 22:37:04', '[swpm_registration_form]', 'Registration', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-01-28 22:37:04', '2018-01-28 22:37:04', '', 5, 'http://localhost/myfirstsite/2018/01/28/5-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-01-28 22:38:03', '2018-01-28 22:38:03', '[swpm_profile_form]', 'Profile', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2018-01-28 22:38:03', '2018-01-28 22:38:03', '', 7, 'http://localhost/myfirstsite/2018/01/28/7-revision-v1/', 0, 'revision', '', 0),
(19, 2, '2018-01-28 22:45:08', '2018-01-28 22:45:08', '', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2018-01-28 22:45:08', '2018-01-28 22:45:08', '', 0, 'http://localhost/myfirstsite/nf_sub/19/', 0, 'nf_sub', '', 0),
(147, 1, '2018-02-06 06:17:40', '2018-02-06 06:17:40', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=\' . $current_user->user_login . \'\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-06 06:17:40', '2018-02-06 06:17:40', '', 34, 'http://localhost/myfirstsite/2018/02/06/34-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', 0, 'http://localhost/myfirstsite/?post_type=ccf_form&#038;p=22', 0, 'ccf_form', '', 0),
(26, 1, '2018-01-28 22:59:23', '2018-01-28 22:59:23', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]\nVolunteer Test Site \"[your-subject]\"\n[your-name] <ehsantos54@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\nehsantos54@gmail.com\nReply-To: [your-email]\n\n0\n0\n\nVolunteer Test Site \"[your-subject]\"\nVolunteer Test Site <ehsantos54@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\n[your-email]\nReply-To: ehsantos54@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2018-01-28 22:59:23', '2018-01-28 22:59:23', '', 0, 'http://localhost/myfirstsite/?post_type=wpcf7_contact_form&p=26', 0, 'wpcf7_contact_form', '', 0),
(24, 1, '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', 'date-2-22', '', 'publish', 'closed', 'closed', '', 'date-2-22', '', '', '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', 22, 'http://localhost/myfirstsite/?post_type=ccf_field&p=24', 0, 'ccf_field', '', 0),
(25, 1, '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', 'single-line-text-1-22', '', 'publish', 'closed', 'closed', '', 'single-line-text-1-22-2', '', '', '2018-01-28 22:54:56', '2018-01-28 22:54:56', '', 22, 'http://localhost/myfirstsite/?post_type=ccf_field&p=25', 0, 'ccf_field', '', 0),
(28, 1, '2018-01-28 23:14:48', '2018-01-28 23:14:48', '<label> Your Name (required)\r\n    [text* your-name] </label>\r\n\r\n<label> Your Email (required)\r\n    [email* your-email] </label>\r\n\r\n<label> Date Performed (required)\r\n    [date* date-916] </label>\r\n\r\n<label> Hours (required)\r\n    [number* number-487] </label>\r\n\r\n<label> Project \r\n    [select menu-282 \"General Work\" \"Fall Festival\"] </label>\r\n\r\n[submit \"Send\"]\n1\nVolunteer Test Site \"[your-subject]\"\n[your-name] <ehsantos54@gmail.com>\nehsantos54@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\nReply-To: [your-email]\n\n\n\n\nVolunteer Test Site \"[your-subject]\"\nVolunteer Test Site <ehsantos54@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Volunteer Test Site (http://localhost/myfirstsite)\nReply-To: ehsantos54@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Add Hours', '', 'publish', 'closed', 'closed', '', 'add-hours', '', '', '2018-01-28 23:14:48', '2018-01-28 23:14:48', '', 0, 'http://localhost/myfirstsite/?post_type=wpcf7_contact_form&p=28', 0, 'wpcf7_contact_form', '', 0),
(31, 1, '2018-02-02 05:42:38', '2018-02-02 05:42:38', '', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-02 05:42:38', '2018-02-02 05:42:38', '', 12, 'http://localhost/myfirstsite/2018/02/02/12-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2018-01-28 23:15:13', '2018-01-28 23:15:13', '[contact-form-7 id=\"28\" title=\"Add Hours\"]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-01-28 23:15:13', '2018-01-28 23:15:13', '', 12, 'http://localhost/myfirstsite/2018/01/28/12-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-02-02 12:55:42', '2018-02-02 12:55:42', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2018-02-02 12:55:42', '2018-02-02 12:55:42', '', 0, 'http://localhost/myfirstsite/?p=41', 2, 'nav_menu_item', '', 0),
(32, 1, '2018-02-02 10:28:29', '2018-02-02 10:28:29', ' [pdb_signup]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-autosave-v1', '', '', '2018-02-02 10:28:29', '2018-02-02 10:28:29', '', 12, 'http://localhost/myfirstsite/2018/02/02/12-autosave-v1/', 0, 'revision', '', 0),
(33, 1, '2018-02-02 10:28:59', '2018-02-02 10:28:59', ' [pdb_signup]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-02 10:28:59', '2018-02-02 10:28:59', '', 12, 'http://localhost/myfirstsite/2018/02/02/12-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2018-02-02 12:34:08', '2018-02-02 12:34:08', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=$current_user->user_login\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'publish', 'closed', 'closed', '', 'volunteer-hours-report', '', '', '2018-02-06 06:27:43', '2018-02-06 06:27:43', '', 0, 'http://localhost/myfirstsite/?page_id=34', 0, 'page', '', 0),
(35, 1, '2018-02-02 12:34:08', '2018-02-02 12:34:08', '[pdb_record]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 12:34:08', '2018-02-02 12:34:08', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-02-02 12:43:18', '2018-02-02 12:43:18', ' [pdb_signup]\r\n\r\n[pdb_signup_thanks]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-02 12:43:18', '2018-02-02 12:43:18', '', 12, 'http://localhost/myfirstsite/2018/02/02/12-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2018-02-02 12:54:42', '2018-02-02 12:54:42', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2018-02-03 00:46:22', '2018-02-03 00:46:22', '', 0, 'http://localhost/myfirstsite/?p=38', 2, 'nav_menu_item', '', 0),
(39, 1, '2018-02-02 12:54:42', '2018-02-02 12:54:42', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2018-02-03 00:46:22', '2018-02-03 00:46:22', '', 0, 'http://localhost/myfirstsite/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2018-02-02 12:54:43', '2018-02-02 12:54:43', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2018-02-03 00:46:22', '2018-02-03 00:46:22', '', 6, 'http://localhost/myfirstsite/?p=40', 5, 'nav_menu_item', '', 0),
(44, 1, '2018-02-02 14:41:43', '2018-02-02 14:41:43', '[pdb_list]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 14:41:43', '2018-02-02 14:41:43', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2018-02-02 13:10:50', '2018-02-02 13:10:50', '[pdb_record]\r\n\r\n[pdb_single]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 13:10:50', '2018-02-02 13:10:50', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2018-02-03 00:33:07', '2018-02-03 00:33:07', '\r\n[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 00:33:07', '2018-02-03 00:33:07', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2018-02-02 17:39:37', '2018-02-02 17:39:37', '\r\n[pdb_list]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 17:39:37', '2018-02-02 17:39:37', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-02-02 15:51:00', '2018-02-02 15:51:00', '[php_everywhere]\r\n[pdb_list]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 15:51:00', '2018-02-02 15:51:00', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-02-02 14:43:11', '2018-02-02 14:43:11', '[insert_php]\r\n$current_user = wp_get_current_user();\r\necho do_shortcode(\'[pdb_list filter=\"user_login=\' . $current_user->user_login . \'\"]\');\r\n[/insert_php]\r\n\r\n[pdb_list]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 14:43:11', '2018-02-02 14:43:11', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-02-02 23:19:24', '2018-02-02 23:19:24', '[pdb_record]\r\n', 'Record Edit', '', 'publish', 'closed', 'closed', '', 'record-edit', '', '', '2018-02-03 08:11:43', '2018-02-03 08:11:43', '', 0, 'http://localhost/myfirstsite/?page_id=48', 0, 'page', '', 0),
(49, 1, '2018-02-02 23:19:24', '2018-02-02 23:19:24', '[pdb_record]', 'Edit Record', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-02 23:19:24', '2018-02-02 23:19:24', '', 48, 'http://localhost/myfirstsite/2018/02/02/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-02-02 23:45:20', '2018-02-02 23:45:20', '[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-02 23:45:20', '2018-02-02 23:45:20', '', 34, 'http://localhost/myfirstsite/2018/02/02/34-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2018-02-03 00:12:59', '2018-02-03 00:12:59', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2018-02-03 00:46:22', '2018-02-03 00:46:22', '', 0, 'http://localhost/myfirstsite/?p=51', 3, 'nav_menu_item', '', 0),
(54, 1, '2018-02-03 00:45:52', '2018-02-03 00:45:52', '[pdb_single]', 'Single Record', '', 'publish', 'closed', 'closed', '', 'single-record', '', '', '2018-02-03 00:56:53', '2018-02-03 00:56:53', '', 0, 'http://localhost/myfirstsite/?page_id=54', 0, 'page', '', 0),
(52, 1, '2018-02-03 00:19:15', '2018-02-03 00:19:15', '[pdb_record]\r\n[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 00:19:15', '2018-02-03 00:19:15', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2018-02-03 00:45:52', '2018-02-03 00:45:52', '[pdb_single]', 'Single Record', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-02-03 00:45:52', '2018-02-03 00:45:52', '', 54, 'http://localhost/myfirstsite/2018/02/03/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-02-03 00:46:22', '2018-02-03 00:46:22', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2018-02-03 00:46:22', '2018-02-03 00:46:22', '', 0, 'http://localhost/myfirstsite/?p=56', 4, 'nav_menu_item', '', 0),
(57, 1, '2018-02-03 02:41:45', '2018-02-03 02:41:45', '[pdb_record]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 02:41:45', '2018-02-03 02:41:45', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-02-03 03:00:12', '2018-02-03 03:00:12', '[php_everywhere]\r\n', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:00:12', '2018-02-03 03:00:12', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-02-03 02:58:29', '2018-02-03 02:58:29', '[php_everywhere]\r\n[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 02:58:29', '2018-02-03 02:58:29', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2018-02-03 03:52:38', '2018-02-03 03:52:38', '[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:52:38', '2018-02-03 03:52:38', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2018-02-03 03:01:46', '2018-02-03 03:01:46', '\r\n[pdb_list template=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:01:46', '2018-02-03 03:01:46', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2018-02-03 03:04:17', '2018-02-03 03:04:17', '[pdb_list templates=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:04:17', '2018-02-03 03:04:17', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2018-02-03 03:48:57', '2018-02-03 03:48:57', '[pdb_list templates=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:48:57', '2018-02-03 03:48:57', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-02-03 03:47:43', '2018-02-03 03:47:43', '[php_everywhere instance=\"1\"]\r\n\r\n[pdb_list templates=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:47:43', '2018-02-03 03:47:43', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2018-02-03 05:06:15', '2018-02-03 05:06:15', '[php_everywhere]\n[pdb_record]\n', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-autosave-v1', '', '', '2018-02-03 05:06:15', '2018-02-03 05:06:15', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-autosave-v1/', 0, 'revision', '', 0),
(64, 1, '2018-02-03 03:49:21', '2018-02-03 03:49:21', '[php_everywhere instance=\"1\"]\r\n[pdb_record]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 03:49:21', '2018-02-03 03:49:21', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2018-02-03 03:51:12', '2018-02-03 03:51:12', '[php_everywhere]\r\n[pdb_record]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 03:51:12', '2018-02-03 03:51:12', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2018-02-03 06:49:27', '2018-02-03 06:49:27', '', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 06:49:27', '2018-02-03 06:49:27', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2018-02-03 03:57:03', '2018-02-03 03:57:03', '[pdb_list templates=edit-link]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 03:57:03', '2018-02-03 03:57:03', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-02-03 04:31:10', '2018-02-03 04:31:10', '\r\n[pdb_record]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 04:31:10', '2018-02-03 04:31:10', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-02-03 04:39:32', '2018-02-03 04:39:32', '[pdb_record templates=edit-link]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 04:39:32', '2018-02-03 04:39:32', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2018-02-03 04:54:39', '2018-02-03 04:54:39', '[php_everywhere]\r\n[pdb_record]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 04:54:39', '2018-02-03 04:54:39', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2018-02-03 04:40:59', '2018-02-03 04:40:59', '[php_everywhere]\r\n[pdb_record templates=edit-link]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 04:40:59', '2018-02-03 04:40:59', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2018-02-03 05:01:07', '2018-02-03 05:01:07', '[pdb_list templates=edit-link]\r\n', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 05:01:07', '2018-02-03 05:01:07', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2018-02-03 04:58:08', '2018-02-03 04:58:08', '[pdb_list templates=edit-link]\r\n[insert_php]\r\necho do_shortcode(\'[pdb_record record_id=\"\' . Participants_Db::get_record_id_by_term(\'user_login\', $current_user->user_login, true) . \'\"]\');\r\n[/insert_php]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 04:58:08', '2018-02-03 04:58:08', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2018-02-03 05:06:57', '2018-02-03 05:06:57', '[php_everywhere]\r\n[pdb_record]\r\n', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 05:06:57', '2018-02-03 05:06:57', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2018-02-03 05:01:28', '2018-02-03 05:01:28', '[php_everywhere]\r\n[pdb_record]\r\n[insert_php]\r\necho do_shortcode(\'[pdb_record record_id=\"\' . Participants_Db::get_record_id_by_term(\'user_login\', $current_user->user_login, true) . \'\"]\');\r\n[/insert_php]', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 05:01:28', '2018-02-03 05:01:28', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2018-02-03 05:08:53', '2018-02-03 05:08:53', '\r\n[pdb_record]\r\n', 'Record Edit', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-02-03 05:08:53', '2018-02-03 05:08:53', '', 48, 'http://localhost/myfirstsite/2018/02/03/48-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2018-02-03 06:49:14', '2018-02-03 06:49:14', '[pdb_list template=edit-link]\r\n', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 06:49:14', '2018-02-03 06:49:14', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2018-02-03 06:49:56', '2018-02-03 06:49:56', '[php anywhere]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 06:49:56', '2018-02-03 06:49:56', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2018-02-03 06:51:58', '2018-02-03 06:51:58', '[pdb_list]\r\n', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 06:51:58', '2018-02-03 06:51:58', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2018-02-03 06:50:50', '2018-02-03 06:50:50', '[php everywhere]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 06:50:50', '2018-02-03 06:50:50', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2018-02-03 07:36:33', '2018-02-03 07:36:33', '[pdb_list template=edit-link]\r\n', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 07:36:33', '2018-02-03 07:36:33', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2018-02-03 11:27:28', '2018-02-03 11:27:28', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:27:28', '2018-02-03 11:27:28', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2018-02-03 09:34:16', '2018-02-03 09:34:16', '[swpm_registration_form level=3]', 'About Us Friends', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2018-02-03 09:34:16', '2018-02-03 09:34:16', '', 10, 'http://localhost/myfirstsite/2018/02/03/10-autosave-v1/', 0, 'revision', '', 0),
(86, 1, '2018-02-03 10:06:53', '2018-02-03 10:06:53', '[pdb_list template=edit-link]\r\n\r\n [pdb_total fields=\"hours\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:06:53', '2018-02-03 10:06:53', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2018-02-03 10:13:28', '2018-02-03 10:13:28', '[pdb_list template=edit-link]\r\n\r\n [pdb_total fields=\"hours\" filter=\"user_login=\' . $current_user->user_login . \'\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:13:28', '2018-02-03 10:13:28', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2018-02-03 10:14:46', '2018-02-03 10:14:46', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=\"hours\" filter=\"user_login=\' . $current_user->user_login . \'\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:14:46', '2018-02-03 10:14:46', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2018-02-03 10:25:46', '2018-02-03 10:25:46', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=\"hours\" ] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:25:46', '2018-02-03 10:25:46', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2018-02-03 10:22:26', '2018-02-03 10:22:26', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\" fields=\"hours\" ] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:22:26', '2018-02-03 10:22:26', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2018-02-03 10:54:58', '2018-02-03 10:54:58', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:54:58', '2018-02-03 10:54:58', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2018-02-03 10:26:45', '2018-02-03 10:26:45', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=\"hours\" filter=\"user_login=\' . $current_user->user_login . \'\" ] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:26:45', '2018-02-03 10:26:45', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2018-02-03 11:00:28', '2018-02-03 11:00:28', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=hours] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:00:28', '2018-02-03 11:00:28', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2018-02-03 10:34:56', '2018-02-03 10:34:56', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=\"hours\" filter=\"user_login=\' . $current_user->user_login . \'\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:34:56', '2018-02-03 10:34:56', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2018-02-03 10:37:27', '2018-02-03 10:37:27', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:37:27', '2018-02-03 10:37:27', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2018-02-03 10:49:18', '2018-02-03 10:49:18', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login=\'. $current_user->user_login . \'\" fields=\'hours\' ] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 10:49:18', '2018-02-03 10:49:18', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2018-02-03 11:02:23', '2018-02-03 11:02:23', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:02:23', '2018-02-03 11:02:23', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2018-02-03 11:05:28', '2018-02-03 11:05:28', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=hours] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:05:28', '2018-02-03 11:05:28', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2018-02-03 11:11:03', '2018-02-03 11:11:03', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3>  ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:11:03', '2018-02-03 11:11:03', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2018-02-03 11:07:36', '2018-02-03 11:07:36', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=hours filter=\"user_login=\' . $current_user->user_login . \'\"] ', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:07:36', '2018-02-03 11:07:36', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2018-02-03 11:11:32', '2018-02-03 11:11:32', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=hours ]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:11:32', '2018-02-03 11:11:32', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2018-02-03 11:16:09', '2018-02-03 11:16:09', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:16:09', '2018-02-03 11:16:09', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2018-02-03 11:40:19', '2018-02-03 11:40:19', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total groups=\"user_login\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:40:19', '2018-02-03 11:40:19', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2018-02-03 11:42:39', '2018-02-03 11:42:39', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total groups=\"$current_user->user_login\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:42:39', '2018-02-03 11:42:39', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2018-02-03 11:44:30', '2018-02-03 11:44:30', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total groups=\"$user_login\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:44:30', '2018-02-03 11:44:30', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2018-02-03 11:43:44', '2018-02-03 11:43:44', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total groups=\"user_login=\'$current_user->user_login\'\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:43:44', '2018-02-03 11:43:44', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2018-02-03 12:07:15', '2018-02-03 12:07:15', '[pdb_list template=edit-link]\r\n\r\n<p>Total Hours:</p> [pdb_total fields=\"hours\"]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:07:15', '2018-02-03 12:07:15', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2018-02-03 12:05:40', '2018-02-03 12:05:40', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:05:40', '2018-02-03 12:05:40', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2018-02-03 11:48:28', '2018-02-03 11:48:28', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total groups=\"user_login=\' . $current_user->user_login . \'\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:48:28', '2018-02-03 11:48:28', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2018-02-03 11:49:45', '2018-02-03 11:49:45', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:49:45', '2018-02-03 11:49:45', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2018-02-03 11:50:14', '2018-02-03 11:50:14', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"user_login=\'$current_user->user_login\'\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:50:14', '2018-02-03 11:50:14', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2018-02-03 11:52:02', '2018-02-03 11:52:02', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total filter=\"\'$current_user->user_login\'\" fields=hours]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 11:52:02', '2018-02-03 11:52:02', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2018-02-03 12:06:06', '2018-02-03 12:06:06', '[pdb_list template=edit-link]\r\n\r\n<h3>Total Hours:</h3> [pdb_total fields=\"hours\"]', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:06:06', '2018-02-03 12:06:06', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2018-02-03 12:07:57', '2018-02-03 12:07:57', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:07:57', '2018-02-03 12:07:57', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2018-02-03 12:26:34', '2018-02-03 12:26:34', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:26:34', '2018-02-03 12:26:34', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2018-02-03 12:23:14', '2018-02-03 12:23:14', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-03 12:23:14', '2018-02-03 12:23:14', '', 34, 'http://localhost/myfirstsite/2018/02/03/34-revision-v1/', 0, 'revision', '', 0),
(119, 1, '2018-02-04 08:40:16', '2018-02-04 08:40:16', '\r\n[pdb_signup]\r\n\r\n[pdb_signup_thanks]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-04 08:40:16', '2018-02-04 08:40:16', '', 12, 'http://localhost/myfirstsite/2018/02/04/12-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2018-02-04 08:35:42', '2018-02-04 08:35:42', '[php_everywhere]\r\n[pdb_signup]\r\n\r\n[pdb_signup_thanks]', 'Add Volunteer Hours', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-04 08:35:42', '2018-02-04 08:35:42', '', 12, 'http://localhost/myfirstsite/2018/02/04/12-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2018-02-04 13:39:41', '2018-02-04 13:39:41', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 13:39:41', '2018-02-04 13:39:41', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2018-02-04 13:35:48', '2018-02-04 13:35:48', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\" filter=\"user_login=\' . $current_user->user_login . \'\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 13:35:48', '2018-02-04 13:35:48', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2018-02-04 14:21:01', '2018-02-04 14:21:01', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:21:01', '2018-02-04 14:21:01', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2018-02-04 14:27:40', '2018-02-04 14:27:40', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:27:40', '2018-02-04 14:27:40', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2018-02-04 14:30:06', '2018-02-04 14:30:06', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total filter=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:30:06', '2018-02-04 14:30:06', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2018-02-04 14:34:43', '2018-02-04 14:34:43', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:34:43', '2018-02-04 14:34:43', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2018-02-04 14:35:40', '2018-02-04 14:35:40', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:35:40', '2018-02-04 14:35:40', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2018-02-04 14:56:10', '2018-02-04 14:56:10', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:56:10', '2018-02-04 14:56:10', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2018-02-04 14:58:30', '2018-02-04 14:58:30', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total ] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:58:30', '2018-02-04 14:58:30', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2018-02-04 14:57:42', '2018-02-04 14:57:42', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 14:57:42', '2018-02-04 14:57:42', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2018-02-04 15:03:05', '2018-02-04 15:03:05', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 15:03:05', '2018-02-04 15:03:05', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2018-02-04 16:04:35', '2018-02-04 16:04:35', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:04:35', '2018-02-04 16:04:35', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(131, 1, '2018-02-04 16:02:09', '2018-02-04 16:02:09', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: echo do_shortcode (‘[pdb_total fields=\"hours\" &amp filter=\"user_login=\' . $current_user->user_login . \'\"]’); </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:02:09', '2018-02-04 16:02:09', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2018-02-04 16:02:38', '2018-02-04 16:02:38', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\" &amp filter=\"user_login=\' . $current_user->user_login . \'\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:02:38', '2018-02-04 16:02:38', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(133, 1, '2018-02-04 16:02:59', '2018-02-04 16:02:59', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\" & filter=\"user_login=\' . $current_user->user_login . \'\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:02:59', '2018-02-04 16:02:59', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2018-02-04 16:03:42', '2018-02-04 16:03:42', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\" &amp fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:03:42', '2018-02-04 16:03:42', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2018-02-04 16:04:17', '2018-02-04 16:04:17', '[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total filter=\"user_login=\' . $current_user->user_login . \'\" fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-04 16:04:17', '2018-02-04 16:04:17', '', 34, 'http://localhost/myfirstsite/2018/02/04/34-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2018-02-05 02:44:02', '2018-02-05 02:44:02', 'Welcome to Friends of Smithgall Woods State Park. This is your first post. Edit or delete it, then start writing!', 'Hello Volunteer!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-02-05 02:44:02', '2018-02-05 02:44:02', '', 1, 'http://localhost/myfirstsite/2018/02/05/1-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2018-02-05 09:10:56', '2018-02-05 09:10:56', '[php_everywhere]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 09:10:56', '2018-02-05 09:10:56', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2018-02-05 09:07:44', '2018-02-05 09:07:44', '[php_everywhere]\r\n[pdb_list template=edit-link]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 09:07:44', '2018-02-05 09:07:44', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2018-02-05 11:04:38', '2018-02-05 11:04:38', '[php_everywhere]\r\n\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 11:04:38', '2018-02-05 11:04:38', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2018-02-05 11:01:55', '2018-02-05 11:01:55', '[php_everywhere]\r\n[php_everywhere]\r\n<h4>Total Hours: [pdb_total fields=\"hours\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 11:01:55', '2018-02-05 11:01:55', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2018-02-05 12:06:13', '2018-02-05 12:06:13', '[php_everywhere instance=\"1\"]\r\n\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 12:06:13', '2018-02-05 12:06:13', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2018-02-05 12:12:31', '2018-02-05 12:12:31', '[php_everywhere instance=\"2\"]\r\n\r\n<h4>Total Hours: [php_everywhere instance=\"1\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 12:12:31', '2018-02-05 12:12:31', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2018-02-05 12:25:05', '2018-02-05 12:25:05', '[php_everywhere instance=\"1\"]\r\n\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 12:25:05', '2018-02-05 12:25:05', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2018-02-05 13:40:27', '2018-02-05 13:40:27', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-05 13:40:27', '2018-02-05 13:40:27', '', 34, 'http://localhost/myfirstsite/2018/02/05/34-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2018-02-06 06:19:23', '2018-02-06 06:19:23', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=\'$current_user->user_login\'\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-06 06:19:23', '2018-02-06 06:19:23', '', 34, 'http://localhost/myfirstsite/2018/02/06/34-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2018-02-06 06:19:58', '2018-02-06 06:19:58', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=\'current_user->user_login\'\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-06 06:19:58', '2018-02-06 06:19:58', '', 34, 'http://localhost/myfirstsite/2018/02/06/34-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2018-02-06 06:20:43', '2018-02-06 06:20:43', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=current_user->user_login\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-06 06:20:43', '2018-02-06 06:20:43', '', 34, 'http://localhost/myfirstsite/2018/02/06/34-revision-v1/', 0, 'revision', '', 0),
(151, 1, '2018-02-06 06:22:55', '2018-02-06 06:22:55', '[php_everywhere instance=\"1\"]\r\n[pdb_total fields=\"hours”]\r\n[pdb_total filter=\"user_login=$current_user->user_login\"]\r\n<h4>Total Hours: [php_everywhere instance=\"2\"] </h4>', 'Volunteer Hours Report', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-02-06 06:22:55', '2018-02-06 06:22:55', '', 34, 'http://localhost/myfirstsite/2018/02/06/34-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_swpm_membership_meta_tbl`
--

DROP TABLE IF EXISTS `wp_swpm_membership_meta_tbl`;
CREATE TABLE IF NOT EXISTS `wp_swpm_membership_meta_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_520_ci,
  `meta_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'text',
  `meta_default` text COLLATE utf8mb4_unicode_520_ci,
  `meta_context` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `level_id` (`level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_swpm_membership_meta_tbl`
--

INSERT INTO `wp_swpm_membership_meta_tbl` (`id`, `level_id`, `meta_key`, `meta_label`, `meta_value`, `meta_type`, `meta_default`, `meta_context`) VALUES
(1, 4, 'swpm_alr_after_login_page_field', '', '', 'text', '', 'swpm_alr');

-- --------------------------------------------------------

--
-- Table structure for table `wp_swpm_membership_tbl`
--

DROP TABLE IF EXISTS `wp_swpm_membership_tbl`;
CREATE TABLE IF NOT EXISTS `wp_swpm_membership_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(127) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'subscriber',
  `permissions` tinyint(4) NOT NULL DEFAULT '0',
  `subscription_period` varchar(11) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '-1',
  `subscription_duration_type` tinyint(4) NOT NULL DEFAULT '0',
  `subscription_unit` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `loginredirect_page` text COLLATE utf8mb4_unicode_520_ci,
  `category_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `page_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `post_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `comment_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `attachment_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `custom_post_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `disable_bookmark_list` longtext COLLATE utf8mb4_unicode_520_ci,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `protect_older_posts` tinyint(1) NOT NULL DEFAULT '0',
  `campaign_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_swpm_membership_tbl`
--

INSERT INTO `wp_swpm_membership_tbl` (`id`, `alias`, `role`, `permissions`, `subscription_period`, `subscription_duration_type`, `subscription_unit`, `loginredirect_page`, `category_list`, `page_list`, `post_list`, `comment_list`, `attachment_list`, `custom_post_list`, `disable_bookmark_list`, `options`, `protect_older_posts`, `campaign_name`) VALUES
(1, 'Content Protection', 'administrator', 15, '0', 0, NULL, NULL, 'N;', 'a:5:{i:0;i:12;i:1;i:7;i:2;i:34;i:3;i:48;i:4;i:54;}', 'a:0:{}', 'N;', 'N;', 'N;', NULL, NULL, 0, ''),
(2, 'Subscriber', 'subscriber', 0, '', 0, NULL, NULL, 'N;', 'a:4:{i:0;i:12;i:1;i:34;i:2;i:48;i:3;i:54;}', 'a:0:{}', 'N;', 'N;', 'N;', NULL, NULL, 0, ''),
(3, 'Author', 'author', 0, '', 0, NULL, NULL, 'N;', 'a:5:{i:0;i:7;i:1;i:12;i:2;i:34;i:3;i:48;i:4;i:54;}', 'a:0:{}', 'N;', 'N;', 'N;', NULL, NULL, 0, ''),
(4, 'Administrator', 'administrator', 0, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_swpm_members_tbl`
--

DROP TABLE IF EXISTS `wp_swpm_members_tbl`;
CREATE TABLE IF NOT EXISTS `wp_swpm_members_tbl` (
  `member_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `first_name` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `last_name` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `member_since` date NOT NULL DEFAULT '0000-00-00',
  `membership_level` smallint(6) NOT NULL,
  `more_membership_levels` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `account_state` enum('active','inactive','expired','pending','unsubscribed') COLLATE utf8mb4_unicode_520_ci DEFAULT 'pending',
  `last_accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_accessed_from_ip` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_street` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_city` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_state` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `address_zipcode` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `home_page` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `gender` enum('male','female','not specified') COLLATE utf8mb4_unicode_520_ci DEFAULT 'not specified',
  `referrer` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `extra_info` text COLLATE utf8mb4_unicode_520_ci,
  `reg_code` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subscription_starts` date DEFAULT NULL,
  `initial_membership_level` smallint(6) DEFAULT NULL,
  `txn_id` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `subscr_id` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `company_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `notes` text COLLATE utf8mb4_unicode_520_ci,
  `flags` int(11) DEFAULT '0',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_swpm_members_tbl`
--

INSERT INTO `wp_swpm_members_tbl` (`member_id`, `user_name`, `first_name`, `last_name`, `password`, `member_since`, `membership_level`, `more_membership_levels`, `account_state`, `last_accessed`, `last_accessed_from_ip`, `email`, `phone`, `address_street`, `address_city`, `address_state`, `address_zipcode`, `home_page`, `country`, `gender`, `referrer`, `extra_info`, `reg_code`, `subscription_starts`, `initial_membership_level`, `txn_id`, `subscr_id`, `company_name`, `notes`, `flags`, `profile_image`) VALUES
(1, 'jdoe', 'John', 'Doe', '$P$BvbakDhyPmTpKvklYGAwN3eHjzzF5s.', '2018-01-28', 3, NULL, 'active', '2018-02-08 14:44:37', '::1', 'jdoe@email.com', '1234567890', '123 No Way', NULL, NULL, NULL, NULL, NULL, 'not specified', NULL, NULL, NULL, '2018-01-28', NULL, '', NULL, '', NULL, 0, ''),
(2, 'rsmith', 'Robert', 'Smith', '$P$BR9H.CAPrQJZaIdXOho7wMwN1rZZNv1', '2018-01-28', 3, NULL, 'active', '2018-02-06 05:50:37', '::1', 'rsmith@email.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not specified', NULL, NULL, NULL, '2018-01-28', NULL, '', '2A', '', NULL, 0, ''),
(3, 'admin', '', 'Admin', '$P$BTj0Q8EBo/Y6Yamz7JNoC0U9ZZraJf1', '2018-02-08', 4, NULL, 'active', '0000-00-00 00:00:00', '', 'admin@email.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not specified', NULL, NULL, NULL, '2018-02-08', NULL, '', '', '', NULL, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_swpm_payments_tbl`
--

DROP TABLE IF EXISTS `wp_swpm_payments_tbl`;
CREATE TABLE IF NOT EXISTS `wp_swpm_payments_tbl` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_name` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `last_name` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `member_id` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `membership_level` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `txn_date` date NOT NULL DEFAULT '0000-00-00',
  `txn_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subscr_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `reference` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `payment_amount` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `gateway` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `status` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `ip_address` varchar(128) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0),
(3, 'User Menu', 'user-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(16, 2, 0),
(51, 3, 0),
(41, 2, 0),
(39, 3, 0),
(38, 3, 0),
(40, 3, 0),
(56, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'ehsantos'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:2:{s:13:\"administrator\";b:1;s:13:\"bbp_keymaster\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(59, 1, 'wp_user-settings', 'editor=html'),
(60, 1, 'wp_user-settings-time', '1517550154'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '146'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:2:\"::\";}'),
(19, 1, 'wp_nf_form_preview_tmp-1517178179', 'a:4:{s:2:\"id\";s:14:\"tmp-1517178179\";s:8:\"settings\";a:18:{s:10:\"objectType\";s:12:\"Form Setting\";s:10:\"editActive\";b:0;s:5:\"title\";s:9:\"Add Hours\";s:10:\"show_title\";i:1;s:14:\"clear_complete\";i:1;s:13:\"hide_complete\";i:1;s:17:\"default_label_pos\";s:5:\"above\";s:13:\"wrapper_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:3:\"key\";s:0:\"\";s:10:\"add_submit\";i:1;s:8:\"currency\";s:0:\"\";s:18:\"unique_field_error\";s:50:\"A form with this value has already been submitted.\";s:9:\"logged_in\";b:0;s:17:\"not_logged_in_msg\";s:0:\"\";s:13:\"sub_limit_msg\";s:42:\"The form has reached its submission limit.\";s:12:\"calculations\";a:0:{}s:15:\"formContentData\";a:5:{i:0;s:28:\"date_performed_1517178228230\";i:1;s:22:\"activity_1517178202399\";i:2;s:21:\"project_1517178259761\";i:3;s:19:\"hours_1517178318434\";i:4;s:20:\"submit_1517178338457\";}}s:6:\"fields\";a:5:{s:5:\"tmp-1\";a:1:{s:8:\"settings\";a:22:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:2;s:4:\"type\";s:7:\"textbox\";s:5:\"label\";s:8:\"Activity\";s:3:\"key\";s:22:\"activity_1517178202399\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:7:\"default\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:11:\"input_limit\";s:0:\"\";s:16:\"input_limit_type\";s:10:\"characters\";s:15:\"input_limit_msg\";s:17:\"Character(s) left\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:4:\"mask\";s:0:\"\";s:11:\"custom_mask\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}}s:5:\"tmp-2\";a:1:{s:8:\"settings\";a:19:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:1;s:4:\"type\";s:4:\"date\";s:5:\"label\";s:14:\"Date Performed\";s:3:\"key\";s:28:\"date_performed_1517178228230\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:11:\"date_format\";s:0:\"\";s:16:\"year_range_start\";s:0:\"\";s:14:\"year_range_end\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}}s:5:\"tmp-3\";a:1:{s:8:\"settings\";a:15:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:999;s:4:\"type\";s:10:\"listselect\";s:5:\"label\";s:7:\"Project\";s:3:\"key\";s:21:\"project_1517178259761\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";b:0;s:7:\"options\";a:2:{i:0;a:9:{s:6:\"errors\";a:0:{}s:11:\"max_options\";i:0;s:5:\"label\";s:12:\"General Work\";s:5:\"value\";s:12:\"General Work\";s:4:\"calc\";s:2:\"gw\";s:8:\"selected\";i:1;s:5:\"order\";i:0;s:12:\"settingModel\";a:10:{s:8:\"settings\";b:0;s:15:\"hide_merge_tags\";b:0;s:5:\"error\";b:0;s:4:\"name\";s:7:\"options\";s:4:\"type\";s:15:\"option-repeater\";s:5:\"label\";s:159:\"Options <a href=\"#\" class=\"nf-add-new\">Add New</a> <a href=\"#\" class=\"extra nf-open-import-tooltip\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Import</a>\";s:5:\"width\";s:4:\"full\";s:5:\"group\";s:0:\"\";s:5:\"value\";a:3:{i:0;a:5:{s:5:\"label\";s:3:\"One\";s:5:\"value\";s:3:\"one\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:0;}i:1;a:5:{s:5:\"label\";s:3:\"Two\";s:5:\"value\";s:3:\"two\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:1;}i:2;a:5:{s:5:\"label\";s:5:\"Three\";s:5:\"value\";s:5:\"three\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:2;}}s:7:\"columns\";a:4:{s:5:\"label\";a:2:{s:6:\"header\";s:5:\"Label\";s:7:\"default\";s:0:\"\";}s:5:\"value\";a:2:{s:6:\"header\";s:5:\"Value\";s:7:\"default\";s:0:\"\";}s:4:\"calc\";a:2:{s:6:\"header\";s:10:\"Calc Value\";s:7:\"default\";s:0:\"\";}s:8:\"selected\";a:2:{s:6:\"header\";s:45:\"<span class=\"dashicons dashicons-yes\"></span>\";s:7:\"default\";i:0;}}}s:12:\"manual_value\";b:1;}i:1;a:9:{s:6:\"errors\";a:0:{}s:11:\"max_options\";i:0;s:5:\"label\";s:13:\"Fall Festival\";s:5:\"value\";s:13:\"Fall Festival\";s:4:\"calc\";s:2:\"ff\";s:8:\"selected\";i:1;s:5:\"order\";i:1;s:12:\"settingModel\";a:10:{s:8:\"settings\";b:0;s:15:\"hide_merge_tags\";b:0;s:5:\"error\";b:0;s:4:\"name\";s:7:\"options\";s:4:\"type\";s:15:\"option-repeater\";s:5:\"label\";s:159:\"Options <a href=\"#\" class=\"nf-add-new\">Add New</a> <a href=\"#\" class=\"extra nf-open-import-tooltip\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Import</a>\";s:5:\"width\";s:4:\"full\";s:5:\"group\";s:0:\"\";s:5:\"value\";a:3:{i:0;a:5:{s:5:\"label\";s:3:\"One\";s:5:\"value\";s:3:\"one\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:0;}i:1;a:5:{s:5:\"label\";s:3:\"Two\";s:5:\"value\";s:3:\"two\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:1;}i:2;a:5:{s:5:\"label\";s:5:\"Three\";s:5:\"value\";s:5:\"three\";s:4:\"calc\";s:0:\"\";s:8:\"selected\";i:0;s:5:\"order\";i:2;}}s:7:\"columns\";a:4:{s:5:\"label\";a:2:{s:6:\"header\";s:5:\"Label\";s:7:\"default\";s:0:\"\";}s:5:\"value\";a:2:{s:6:\"header\";s:5:\"Value\";s:7:\"default\";s:0:\"\";}s:4:\"calc\";a:2:{s:6:\"header\";s:10:\"Calc Value\";s:7:\"default\";s:0:\"\";}s:8:\"selected\";a:2:{s:6:\"header\";s:45:\"<span class=\"dashicons dashicons-yes\"></span>\";s:7:\"default\";i:0;}}}s:12:\"manual_value\";b:1;}}s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:14:\"drawerDisabled\";b:0;}}s:5:\"tmp-4\";a:1:{s:8:\"settings\";a:20:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:999;s:4:\"type\";s:6:\"number\";s:5:\"label\";s:5:\"Hours\";s:3:\"key\";s:19:\"hours_1517178318434\";s:9:\"label_pos\";s:7:\"default\";s:8:\"required\";i:1;s:7:\"default\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:10:\"manual_key\";b:0;s:11:\"admin_label\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:7:\"num_min\";s:1:\"0\";s:7:\"num_max\";s:0:\"\";s:8:\"num_step\";s:1:\"1\";s:14:\"drawerDisabled\";b:0;}}s:5:\"tmp-5\";a:1:{s:8:\"settings\";a:10:{s:10:\"objectType\";s:5:\"Field\";s:12:\"objectDomain\";s:6:\"fields\";s:10:\"editActive\";b:0;s:5:\"order\";i:9999;s:4:\"type\";s:6:\"submit\";s:5:\"label\";s:6:\"Submit\";s:16:\"processing_label\";s:10:\"Processing\";s:15:\"container_class\";s:0:\"\";s:13:\"element_class\";s:0:\"\";s:3:\"key\";s:20:\"submit_1517178338457\";}}}s:7:\"actions\";a:3:{s:5:\"tmp-1\";a:1:{s:8:\"settings\";a:23:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:15:\"Success Message\";s:4:\"type\";s:14:\"successmessage\";s:7:\"message\";s:42:\"Your form has been successfully submitted.\";s:5:\"order\";i:1;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";s:11:\"success_msg\";s:42:\"Your form has been successfully submitted.\";}}s:5:\"tmp-2\";a:1:{s:8:\"settings\";a:20:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:11:\"Admin Email\";s:4:\"type\";s:5:\"email\";s:5:\"order\";i:2;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";}}s:5:\"tmp-3\";a:1:{s:8:\"settings\";a:21:{s:10:\"objectType\";s:6:\"Action\";s:12:\"objectDomain\";s:7:\"actions\";s:10:\"editActive\";b:0;s:5:\"label\";s:16:\"Store Submission\";s:4:\"type\";s:4:\"save\";s:5:\"order\";i:3;s:6:\"active\";b:1;s:16:\"payment_gateways\";s:0:\"\";s:13:\"payment_total\";s:1:\"0\";s:3:\"tag\";s:0:\"\";s:2:\"to\";s:16:\"{wp:admin_email}\";s:8:\"reply_to\";s:0:\"\";s:13:\"email_subject\";s:22:\"Ninja Forms Submission\";s:13:\"email_message\";s:14:\"{fields_table}\";s:19:\"email_message_plain\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:12:\"from_address\";s:0:\"\";s:12:\"email_format\";s:4:\"html\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"redirect_url\";s:0:\"\";}}}}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:19:\"add-post-type-forum\";i:1;s:20:\"add-post-type-nf_sub\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";}'),
(22, 2, 'nickname', 'jdoe'),
(23, 2, 'first_name', 'John'),
(24, 2, 'last_name', 'Doe'),
(25, 2, 'description', ''),
(26, 2, 'rich_editing', 'true'),
(27, 2, 'syntax_highlighting', 'true'),
(28, 2, 'comment_shortcuts', 'false'),
(29, 2, 'admin_color', 'fresh'),
(30, 2, 'use_ssl', '0'),
(31, 2, 'show_admin_bar_front', 'true'),
(32, 2, 'locale', ''),
(33, 2, 'wp_capabilities', 'a:2:{s:10:\"subscriber\";b:1;s:15:\"bbp_participant\";b:1;}'),
(34, 2, 'wp_user_level', '0'),
(36, 1, 'manageedit-nf_subcolumnshidden', 'a:0:{}'),
(37, 1, 'closedpostboxes_ccf_form', 'a:0:{}'),
(38, 1, 'metaboxhidden_ccf_form', 'a:0:{}'),
(40, 1, 'nav_menu_recently_edited', '3'),
(41, 3, 'nickname', 'rsmith'),
(42, 3, 'first_name', 'Robert'),
(43, 3, 'last_name', 'Smith'),
(44, 3, 'description', ''),
(39, 2, 'community-events-location', 'a:1:{s:2:\"ip\";s:2:\"::\";}'),
(45, 3, 'rich_editing', 'true'),
(46, 3, 'syntax_highlighting', 'true'),
(47, 3, 'comment_shortcuts', 'false'),
(48, 3, 'admin_color', 'fresh'),
(49, 3, 'use_ssl', '0'),
(50, 3, 'show_admin_bar_front', 'true'),
(51, 3, 'locale', ''),
(52, 3, 'wp_capabilities', 'a:2:{s:10:\"subscriber\";b:1;s:15:\"bbp_participant\";b:1;}'),
(53, 3, 'wp_user_level', '0'),
(87, 4, 'nickname', 'admin'),
(88, 4, 'first_name', ''),
(89, 4, 'last_name', 'Admin'),
(90, 4, 'description', ''),
(91, 4, 'rich_editing', 'true'),
(92, 4, 'syntax_highlighting', 'true'),
(85, 1, 'session_tokens', 'a:1:{s:64:\"d0b5e6f3002d2d786d36057f25521cf31af602bc05aa8afd283013df73f20a4b\";a:4:{s:10:\"expiration\";i:1518273418;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36\";s:5:\"login\";i:1518100618;}}'),
(64, 1, 'closedpostboxes_page', 'a:0:{}'),
(65, 1, 'metaboxhidden_page', 'a:6:{i:0;s:12:\"revisionsdiv\";i:1;s:10:\"postcustom\";i:2;s:16:\"commentstatusdiv\";i:3;s:11:\"commentsdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}'),
(93, 4, 'comment_shortcuts', 'false'),
(94, 4, 'admin_color', 'fresh'),
(95, 4, 'use_ssl', '0'),
(96, 4, 'show_admin_bar_front', 'true'),
(97, 4, 'locale', ''),
(98, 4, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(99, 4, 'wp_user_level', '0');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'ehsantos', '$P$BChxaTyyMggvLuhTfTvmzlvAs9Q0vL1', 'ehsantos', 'ehsantos54@gmail.com', '', '2018-01-28 22:18:36', '', 0, 'ehsantos'),
(2, 'jdoe', '$P$BvbakDhyPmTpKvklYGAwN3eHjzzF5s.', 'jdoe', 'jdoe@email.com', '', '2018-01-28 22:42:13', '', 0, 'jdoe'),
(3, 'rsmith', '$P$BR9H.CAPrQJZaIdXOho7wMwN1rZZNv1', 'rsmith', 'rsmith@email.com', '', '2018-01-28 23:59:46', '', 0, 'rsmith'),
(4, 'admin', '$P$BTj0Q8EBo/Y6Yamz7JNoC0U9ZZraJf1', 'admin', 'admin@email.com', '', '2018-02-08 16:03:36', '', 0, 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
